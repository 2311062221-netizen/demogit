package com.example.nckh;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.graphics.Insets;
import androidx.core.util.Pair;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.TimeZone;

public class MainActivity extends AppCompatActivity {

    private FloatingActionButton fabThemGiaoDich;
    private BottomNavigationView bottomNavigation;
    private TextView tvTongSoDu;
    private CardView cvThayDoiRong, cvNhungCotMoc, cvPhanTichThem;
    private CardView cvLoaiThoiGian, cvChonNgayThang;
    private TextView tvLoaiThoiGian, tvChonNgayThang;

    private String cheDoThoiGian = "Tháng";
    private DatabaseHelper dbHelper;

    // Biến chức năng lọc thu chi
    private int boLocHienTai = 0; // 0: Tất cả, 1: Thu Nhập, 2: Chi Phí
    private TextView tvTongThuNhapCard, tvTongChiPhiCard;
    private View btnLocChiPhi, btnLocThuNhap;

    // ==========================================
    // CÁC BIẾN CHO CHỨC NĂNG QUẢN LÝ VÍ
    // ==========================================
    private ImageView ivEditWallet;
    private TextView tvTenVi;
    private CardView cvViMoi;
    private SharedPreferences sharedPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);
        // Khởi tạo SharedPreferences để lưu Số dư ban đầu và Tên ví
        sharedPreferences = getSharedPreferences("WalletData", MODE_PRIVATE);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Ánh xạ View
        fabThemGiaoDich = findViewById(R.id.fabThemGiaoDich);
        bottomNavigation = findViewById(R.id.bottom_navigation);
        tvTongSoDu = findViewById(R.id.tvTongSoDu);
        cvThayDoiRong = findViewById(R.id.cvThayDoiRong);
        cvNhungCotMoc = findViewById(R.id.cvNhungCotMoc);
        cvPhanTichThem = findViewById(R.id.cvPhanTichThem);
        cvLoaiThoiGian = findViewById(R.id.cvLoaiThoiGian);
        tvLoaiThoiGian = findViewById(R.id.tvLoaiThoiGian);
        cvChonNgayThang = findViewById(R.id.cvChonNgayThang);
        tvChonNgayThang = findViewById(R.id.tvChonNgayThang);
        tvTongThuNhapCard = findViewById(R.id.tvTongThuNhapCard);
        tvTongChiPhiCard = findViewById(R.id.tvTongChiPhiCard);
        btnLocChiPhi = findViewById(R.id.btnFilterChiPhi);
        btnLocThuNhap = findViewById(R.id.btnFilterThuNhap);

        // Ánh xạ thành phần Quản lý Ví
        ivEditWallet = findViewById(R.id.ivEditWallet);
        tvTenVi = findViewById(R.id.tvTenVi);
        cvViMoi = findViewById(R.id.cvViMoi);

        View layoutCardChiPhi = findViewById(R.id.layoutCardChiPhi);
        View layoutCardThuNhap = findViewById(R.id.layoutCardThuNhap);

        // Bắt sự kiện Lọc
        View.OnClickListener clickLocChiPhi = v -> thietLapBoLoc(2);
        View.OnClickListener clickLocThuNhap = v -> thietLapBoLoc(1);

        if(btnLocChiPhi != null) btnLocChiPhi.setOnClickListener(clickLocChiPhi);
        if(btnLocThuNhap != null) btnLocThuNhap.setOnClickListener(clickLocThuNhap);
        if(layoutCardChiPhi != null) layoutCardChiPhi.setOnClickListener(clickLocChiPhi);
        if(layoutCardThuNhap != null) layoutCardThuNhap.setOnClickListener(clickLocThuNhap);

        // Bắt sự kiện quản lý ví
        if(ivEditWallet != null) ivEditWallet.setOnClickListener(v -> hienThiDialogChinhSuaVi());
        if(cvViMoi != null) cvViMoi.setOnClickListener(v -> hienThiDialogTaoViMoi());

        // ĐÃ THAY THẾ: Nút FAB Dấu Cộng giờ đây sẽ mở AI Chatbot thay vì Form nhập tay cũ
        fabThemGiaoDich.setOnClickListener(v -> {
            Intent intent = new Intent(MainActivity.this, ChatBotActivity.class);
            startActivity(intent);
        });

        cvLoaiThoiGian.setOnClickListener(v -> hienThiMenuLoaiThoiGian());
        cvChonNgayThang.setOnClickListener(v -> xuLyChonThoiGianChiTiet());

        if(cvNhungCotMoc != null) cvNhungCotMoc.setOnClickListener(v -> hienThiNhungCotMoc());
        if(cvPhanTichThem != null) cvPhanTichThem.setOnClickListener(v -> hienThiMenuPhanTich());

        bottomNavigation.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.nav_home) return true;
            else if (itemId == R.id.nav_calendar) {
                startActivity(new Intent(MainActivity.this, CalendarActivity.class));
                return false;
            } else if (itemId == R.id.nav_chart) {
                startActivity(new Intent(MainActivity.this, ChartActivity.class));
                return false;
            } else if (itemId == R.id.nav_ai_chat) {
                // Trỏ đến màn hình AI Chat
                startActivity(new Intent(MainActivity.this, ChatBotActivity.class));
                return false;
            }
            return false;
        });
    }

    // Tự động tải lại dữ liệu mỗi khi quay về từ ChatBot
    @Override
    protected void onResume() {
        super.onResume();
        taiDuLieuTuDatabase();
    }

    // ==========================================
    // CÁC HÀM QUẢN LÝ VÍ (CHỈNH SỬA & TẠO MỚI)
    // ==========================================
    private void hienThiDialogChinhSuaVi() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Chỉnh sửa thông tin ví");

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(dpToPx(24), dpToPx(16), dpToPx(24), dpToPx(8));

        // Nhập tên ví
        final EditText inputTenVi = new EditText(this);
        inputTenVi.setHint("Nhập tên ví (VD: Tiền mặt, Thẻ tín dụng)");
        String tenHienTai = sharedPreferences.getString("TEN_VI", "Dung");
        inputTenVi.setText(tenHienTai);
        layout.addView(inputTenVi);

        // Nhập số dư ban đầu
        final EditText inputSoDuBanDau = new EditText(this);
        inputSoDuBanDau.setHint("Số dư ban đầu (VNĐ)");
        inputSoDuBanDau.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_SIGNED);
        long soDuBanDauHienTai = sharedPreferences.getLong("SO_DU_BAN_DAU", 0);
        if (soDuBanDauHienTai != 0) {
            inputSoDuBanDau.setText(String.valueOf(soDuBanDauHienTai));
        }
        layout.addView(inputSoDuBanDau);

        builder.setView(layout);

        builder.setPositiveButton("Lưu thay đổi", (dialog, which) -> {
            String tenViMoi = inputTenVi.getText().toString().trim();
            String soDuMoiStr = inputSoDuBanDau.getText().toString().trim();
            long soDuBanDauMoi = 0;

            if (!soDuMoiStr.isEmpty()) {
                try {
                    soDuBanDauMoi = Long.parseLong(soDuMoiStr);
                } catch (NumberFormatException e) {
                    Toast.makeText(MainActivity.this, "Số dư không hợp lệ!", Toast.LENGTH_SHORT).show();
                    return;
                }
            }

            if(tenViMoi.isEmpty()) tenViMoi = "Ví của tôi";

            // Lưu lại thông tin mới
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("TEN_VI", tenViMoi);
            editor.putLong("SO_DU_BAN_DAU", soDuBanDauMoi);
            editor.apply();

            // Load lại màn hình
            taiDuLieuTuDatabase();
            Toast.makeText(MainActivity.this, "Cập nhật ví thành công!", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Hủy", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void hienThiDialogTaoViMoi() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Tạo Ví Mới");
        builder.setMessage("Tạo ví mới sẽ thay thế tên ví và số dư ban đầu hiện tại. Bạn có muốn tiếp tục?");

        android.widget.LinearLayout layout = new android.widget.LinearLayout(this);
        layout.setOrientation(android.widget.LinearLayout.VERTICAL);
        layout.setPadding(dpToPx(24), dpToPx(8), dpToPx(24), dpToPx(8));

        final EditText inputTenViMoi = new EditText(this);
        inputTenViMoi.setHint("Tên ví mới (VD: Ví tiết kiệm)");
        layout.addView(inputTenViMoi);

        final EditText inputSoDu = new EditText(this);
        inputSoDu.setHint("Số dư hiện tại (VNĐ)");
        inputSoDu.setInputType(InputType.TYPE_CLASS_NUMBER);
        layout.addView(inputSoDu);

        builder.setView(layout);

        builder.setPositiveButton("Tạo", (dialog, which) -> {
            String ten = inputTenViMoi.getText().toString().trim();
            String soDuStr = inputSoDu.getText().toString().trim();
            long soDu = 0;

            if(!soDuStr.isEmpty()){
                try { soDu = Long.parseLong(soDuStr); } catch (Exception ignored){}
            }
            if(ten.isEmpty()) ten = "Ví mới";

            // Reset và gán số dư mới
            SharedPreferences.Editor editor = sharedPreferences.edit();
            editor.putString("TEN_VI", ten);
            editor.putLong("SO_DU_BAN_DAU", soDu);
            editor.apply();

            taiDuLieuTuDatabase();
            Toast.makeText(MainActivity.this, "Đã khởi tạo ví mới!", Toast.LENGTH_SHORT).show();
        });

        builder.setNegativeButton("Hủy", (dialog, which) -> dialog.cancel());
        builder.show();
    }

    private void thietLapBoLoc(int loai) {
        if (boLocHienTai == loai) boLocHienTai = 0;
        else boLocHienTai = loai;
        taiDuLieuTuDatabase();
    }

    private void taiDuLieuTuDatabase() {
        try {
            android.widget.LinearLayout llDanhSach = findViewById(R.id.llDanhSachGiaoDichContainer);
            if(llDanhSach != null) llDanhSach.removeAllViews();

            Cursor cursor = dbHelper.layTatCaGiaoDich();
            DecimalFormat formatter = new DecimalFormat("#,###");

            boolean hasData = false;

            while (cursor.moveToNext()) {
                int loai = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LOAI_GIAO_DICH));

                if (boLocHienTai != 0 && loai != boLocHienTai) {
                    continue;
                }

                hasData = true;
                long soTien = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_SO_TIEN));
                String danhMuc = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DANH_MUC));
                String ghiChu = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_GHI_CHU));

                String formattedTien = formatter.format(soTien).replace(",", ".");
                if(llDanhSach != null) hienThiGiaoDichMoiLenManHinh(llDanhSach, formattedTien, danhMuc, ghiChu, loai);
            }

            if (!hasData && llDanhSach != null) {
                TextView tvRong = new TextView(this);
                if(boLocHienTai == 1) tvRong.setText("Chưa có giao dịch Thu nhập nào");
                else if (boLocHienTai == 2) tvRong.setText("Chưa có giao dịch Chi phí nào");
                else tvRong.setText("Chưa có giao dịch");

                tvRong.setGravity(android.view.Gravity.CENTER);
                tvRong.setPadding(0, dpToPx(20), 0, dpToPx(20));
                llDanhSach.addView(tvRong);
            }

            cursor.close();

            // Cập nhật giao diện Tiền tệ và Tên ví
            capNhatSoDuTong();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void capNhatSoDuTong() {
        long soDuBanDau = sharedPreferences.getLong("SO_DU_BAN_DAU", 0);
        String tenVi = sharedPreferences.getString("TEN_VI", "Dung");

        long tongThu = dbHelper.layTongTienTheoLoai(1);
        long tongChi = dbHelper.layTongTienTheoLoai(2);
        long soDu = soDuBanDau + tongThu - tongChi;

        DecimalFormat formatter = new DecimalFormat("#,###");

        if (tvTenVi != null) {
            tvTenVi.setText(tenVi);
        }

        if (tvTongSoDu != null) {
            tvTongSoDu.setText(formatter.format(soDu).replace(",", ".") + "đ");
        }

        if (tvTongThuNhapCard != null) {
            tvTongThuNhapCard.setText("▲ " + formatter.format(tongThu).replace(",", ".") + "đ");
        }

        if (tvTongChiPhiCard != null) {
            tvTongChiPhiCard.setText("▼ " + formatter.format(tongChi).replace(",", ".") + "đ");
        }
    }

    private void hienThiGiaoDichMoiLenManHinh(android.widget.LinearLayout llDanhSach, String soTien, String danhMuc, String ghiChu, int loaiGiaoDich) {
        CardView card = new CardView(this);
        android.widget.LinearLayout.LayoutParams cardParams = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, dpToPx(8), 0, dpToPx(8));
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(16));
        card.setCardElevation(dpToPx(2));
        card.setCardBackgroundColor(android.graphics.Color.WHITE);

        android.widget.LinearLayout inner = new android.widget.LinearLayout(this);
        inner.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        inner.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        inner.setGravity(android.view.Gravity.CENTER_VERTICAL);

        ImageView icon = new ImageView(this);
        icon.setImageResource(loaiGiaoDich == 1 ? android.R.drawable.ic_input_add : android.R.drawable.ic_menu_agenda);
        icon.setColorFilter(android.graphics.Color.parseColor(loaiGiaoDich == 1 ? "#4CAF50" : "#FF9800"));
        android.widget.LinearLayout.LayoutParams iconParams = new android.widget.LinearLayout.LayoutParams(dpToPx(36), dpToPx(36));
        iconParams.setMarginEnd(dpToPx(16));
        inner.addView(icon, iconParams);

        android.widget.LinearLayout textCol = new android.widget.LinearLayout(this);
        textCol.setOrientation(android.widget.LinearLayout.VERTICAL);
        textCol.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

        TextView tvCat = new TextView(this);
        tvCat.setText(danhMuc == null || danhMuc.isEmpty() ? (loaiGiaoDich == 1 ? "Thu nhập khác" : "Chi tiêu chung") : danhMuc);
        tvCat.setTextSize(16);
        tvCat.setTypeface(null, android.graphics.Typeface.BOLD);
        tvCat.setTextColor(android.graphics.Color.parseColor("#333333"));
        textCol.addView(tvCat);

        if (ghiChu != null && !ghiChu.isEmpty()) {
            TextView tvNote = new TextView(this);
            tvNote.setText(ghiChu);
            tvNote.setTextSize(13);
            tvNote.setTextColor(android.graphics.Color.parseColor("#888888"));
            textCol.addView(tvNote);
        }
        inner.addView(textCol);

        TextView tvAmt = new TextView(this);
        String prefix = (loaiGiaoDich == 1) ? "+" : "-";
        String colorHex = (loaiGiaoDich == 1) ? "#4CAF50" : "#FF4B4B";

        tvAmt.setText(prefix + (soTien == null || soTien.isEmpty() ? "0" : soTien) + " đ");
        tvAmt.setTextSize(16);
        tvAmt.setTypeface(null, android.graphics.Typeface.BOLD);
        tvAmt.setTextColor(android.graphics.Color.parseColor(colorHex));
        inner.addView(tvAmt);

        card.addView(inner);
        llDanhSach.addView(card);
    }

    private void hienThiChiTietThayDoiRong() {
        long tongThu = dbHelper.layTongTienTheoLoai(1);
        long tongChi = dbHelper.layTongTienTheoLoai(2);
        long soDu = tongThu - tongChi;

        DecimalFormat fmt = new DecimalFormat("#,###");
        String strThu = fmt.format(tongThu).replace(",", ".");
        String strChi = fmt.format(tongChi).replace(",", ".");
        String strTong = fmt.format(soDu).replace(",", ".");

        new AlertDialog.Builder(this)
                .setTitle("Chi tiết Thay đổi dòng")
                .setMessage("🔹 Thu nhập: +" + strThu + " đ\n🔸 Chi phí: -" + strChi + " đ\n-----------------------\n💰 Tổng cộng: " + strTong + " đ")
                .setPositiveButton("Đóng", (dialog, which) -> dialog.dismiss())
                .show();
    }

    private void hienThiMenuPhanTich() {
        com.google.android.material.bottomsheet.BottomSheetDialog dialog = taoBottomSheetDialogChung("Phân tích & Cố vấn");
        android.widget.LinearLayout listContainer = new android.widget.LinearLayout(this);
        listContainer.setOrientation(android.widget.LinearLayout.VERTICAL);

        // Mở AiChatActivity (Cố vấn AI)
        View.OnClickListener clickAI = v -> { dialog.dismiss(); startActivity(new Intent(MainActivity.this, AiChatActivity.class)); };
        listContainer.addView(taoOPhanTich("Cố vấn tài chính AI", "Phân tích thông minh & đưa ra lời khuyên", android.R.drawable.ic_menu_help, "#673AB7", "#EDE7F6", clickAI));

        View.OnClickListener clickChart = v -> { dialog.dismiss(); startActivity(new Intent(MainActivity.this, ChartActivity.class)); };
        listContainer.addView(taoOPhanTich("Biểu đồ xu hướng", "Theo dõi mức chi tiêu qua từng giai đoạn", android.R.drawable.ic_menu_sort_by_size, "#00BCD4", "#E0F7FA", clickChart));
        View.OnClickListener clickCalendar = v -> { dialog.dismiss(); startActivity(new Intent(MainActivity.this, CalendarActivity.class)); };
        listContainer.addView(taoOPhanTich("Lịch chi tiêu", "Xem chi tiết giao dịch theo chế độ Lịch", android.R.drawable.ic_menu_month, "#FF9800", "#FFF3E0", clickCalendar));
        hoanThienBottomSheet(dialog, listContainer);
    }

    private CardView taoOPhanTich(String tieuDe, String moTa, int iconRes, String mauIcon, String mauNenIcon, View.OnClickListener listener) {
        CardView card = new CardView(this);
        android.widget.LinearLayout.LayoutParams cardParams = new android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dpToPx(12));
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(16));
        card.setCardElevation(0);
        card.setCardBackgroundColor(android.graphics.Color.parseColor("#F8F9FA"));
        android.util.TypedValue outValue = new android.util.TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
        card.setForeground(getDrawable(outValue.resourceId));
        card.setClickable(true);
        card.setOnClickListener(listener);
        android.widget.LinearLayout inner = new android.widget.LinearLayout(this);
        inner.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        inner.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        inner.setGravity(android.view.Gravity.CENTER_VERTICAL);
        CardView iconWrapper = new CardView(this);
        iconWrapper.setRadius(dpToPx(24));
        iconWrapper.setCardElevation(0);
        iconWrapper.setCardBackgroundColor(android.graphics.Color.parseColor(mauNenIcon));
        android.widget.LinearLayout.LayoutParams iconParams = new android.widget.LinearLayout.LayoutParams(dpToPx(48), dpToPx(48));
        iconParams.setMarginEnd(dpToPx(16));
        iconWrapper.setLayoutParams(iconParams);
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(android.graphics.Color.parseColor(mauIcon));
        icon.setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12));
        iconWrapper.addView(icon);
        inner.addView(iconWrapper);
        android.widget.LinearLayout textCol = new android.widget.LinearLayout(this);
        textCol.setOrientation(android.widget.LinearLayout.VERTICAL);
        textCol.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
        TextView tvTitle = new TextView(this);
        tvTitle.setText(tieuDe);
        tvTitle.setTextSize(16);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(android.graphics.Color.parseColor("#333333"));
        textCol.addView(tvTitle);
        TextView tvDesc = new TextView(this);
        tvDesc.setText(moTa);
        tvDesc.setTextSize(13);
        tvDesc.setTextColor(android.graphics.Color.parseColor("#888888"));
        tvDesc.setPadding(0, dpToPx(4), 0, 0);
        textCol.addView(tvDesc);
        inner.addView(textCol);
        TextView tvArrow = new TextView(this);
        tvArrow.setText("›");
        tvArrow.setTextSize(28);
        tvArrow.setTextColor(android.graphics.Color.parseColor("#CCCCCC"));
        inner.addView(tvArrow);
        card.addView(inner);
        return card;
    }

    private void hienThiNhungCotMoc() {
        com.google.android.material.bottomsheet.BottomSheetDialog dialog = taoBottomSheetDialogChung("Thành tựu & Cột mốc");
        android.widget.LinearLayout rootLayout = new android.widget.LinearLayout(this);
        rootLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
        CardView cvStreak = new CardView(this);
        cvStreak.setRadius(dpToPx(16));
        cvStreak.setCardElevation(0);
        cvStreak.setCardBackgroundColor(android.graphics.Color.parseColor("#FFF3E0"));
        android.widget.LinearLayout.LayoutParams streakParams = new android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        streakParams.bottomMargin = dpToPx(16);
        cvStreak.setLayoutParams(streakParams);
        android.widget.LinearLayout streakLayout = new android.widget.LinearLayout(this);
        streakLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        streakLayout.setPadding(dpToPx(20), dpToPx(20), dpToPx(20), dpToPx(20));
        streakLayout.setGravity(android.view.Gravity.CENTER_VERTICAL);
        TextView tvFlame = new TextView(this);
        tvFlame.setText("🔥");
        tvFlame.setTextSize(40);
        streakLayout.addView(tvFlame);
        android.widget.LinearLayout streakTextLayout = new android.widget.LinearLayout(this);
        streakTextLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
        streakTextLayout.setPadding(dpToPx(16), 0, 0, 0);
        TextView tvStreakNum = new TextView(this);
        tvStreakNum.setText("3 Ngày Liên Tiếp");
        tvStreakNum.setTextSize(18);
        tvStreakNum.setTypeface(null, android.graphics.Typeface.BOLD);
        tvStreakNum.setTextColor(android.graphics.Color.parseColor("#E65100"));
        streakTextLayout.addView(tvStreakNum);
        TextView tvStreakDesc = new TextView(this);
        tvStreakDesc.setText("Tuyệt vời! Bạn đang duy trì thói quen rất tốt.");
        tvStreakDesc.setTextSize(13);
        tvStreakDesc.setTextColor(android.graphics.Color.parseColor("#F57C00"));
        streakTextLayout.addView(tvStreakDesc);
        streakLayout.addView(streakTextLayout);
        cvStreak.addView(streakLayout);
        rootLayout.addView(cvStreak);
        TextView tvCalTitle = new TextView(this);
        tvCalTitle.setText("Hoạt động tháng này");
        tvCalTitle.setTextSize(16);
        tvCalTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvCalTitle.setTextColor(android.graphics.Color.BLACK);
        tvCalTitle.setPadding(0, dpToPx(8), 0, dpToPx(12));
        rootLayout.addView(tvCalTitle);
        rootLayout.addView(taoLichHoatDongMock());
        TextView tvAchTitle = new TextView(this);
        tvAchTitle.setText("Huy hiệu của bạn");
        tvAchTitle.setTextSize(16);
        tvAchTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvAchTitle.setTextColor(android.graphics.Color.BLACK);
        tvAchTitle.setPadding(0, dpToPx(20), 0, dpToPx(12));
        rootLayout.addView(tvAchTitle);
        android.widget.LinearLayout row1 = new android.widget.LinearLayout(this);
        row1.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        row1.addView(taoOThanhTuu("👑 Chuỗi dài nhất", "Kỷ lục: 12 ngày", true, "#E8F5E9", "#2E7D32"));
        row1.addView(taoOThanhTuu("⭐ Tuần hoàn hảo", "Full 7 ngày", true, "#FFF8E1", "#F57F17"));
        rootLayout.addView(row1);
        android.widget.LinearLayout row2 = new android.widget.LinearLayout(this);
        row2.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        row2.addView(taoOThanhTuu("🦉 Cú đêm", "Nhập sau 22h", true, "#EDE7F6", "#4527A0"));
        row2.addView(taoOThanhTuu("🏆 Tháng hoàng kim", "Full 30 ngày", false, "#F5F5F5", "#9E9E9E"));
        rootLayout.addView(row2);
        hoanThienBottomSheet(dialog, rootLayout);
    }

    private CardView taoLichHoatDongMock() {
        CardView cardCal = new CardView(this);
        cardCal.setRadius(dpToPx(12));
        cardCal.setCardElevation(0);
        cardCal.setCardBackgroundColor(android.graphics.Color.parseColor("#F8F9FA"));
        android.widget.LinearLayout calContainer = new android.widget.LinearLayout(this);
        calContainer.setOrientation(android.widget.LinearLayout.VERTICAL);
        calContainer.setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12));
        android.widget.LinearLayout headerRow = new android.widget.LinearLayout(this);
        headerRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        headerRow.setWeightSum(7);
        String[] daysOfWeek = {"T2", "T3", "T4", "T5", "T6", "T7", "CN"};
        for (String d : daysOfWeek) {
            TextView tv = new TextView(this);
            tv.setText(d);
            tv.setTextSize(12);
            tv.setTextColor(android.graphics.Color.parseColor("#888888"));
            tv.setGravity(android.view.Gravity.CENTER);
            tv.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
            headerRow.addView(tv);
        }
        calContainer.addView(headerRow);
        Calendar cal = Calendar.getInstance();
        int today = cal.get(Calendar.DAY_OF_MONTH);
        int maxDays = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        cal.set(Calendar.DAY_OF_MONTH, 1);
        int firstDayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        int emptySlots = (firstDayOfWeek == Calendar.SUNDAY) ? 6 : firstDayOfWeek - 2;
        int currentDay = 1;
        for (int row = 0; row < 6; row++) {
            android.widget.LinearLayout dayRow = new android.widget.LinearLayout(this);
            dayRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
            dayRow.setWeightSum(7);
            dayRow.setPadding(0, dpToPx(8), 0, 0);
            for (int col = 0; col < 7; col++) {
                TextView tvDay = new TextView(this);
                tvDay.setGravity(android.view.Gravity.CENTER);
                tvDay.setTextSize(14);
                android.widget.LinearLayout.LayoutParams params = new android.widget.LinearLayout.LayoutParams(0, dpToPx(32), 1.0f);
                params.setMargins(dpToPx(2), 0, dpToPx(2), 0);
                tvDay.setLayoutParams(params);
                if (row == 0 && col < emptySlots) {
                    tvDay.setText("");
                } else if (currentDay <= maxDays) {
                    tvDay.setText(String.valueOf(currentDay));
                    if (currentDay == today || currentDay == today - 1 || currentDay == today - 2) {
                        tvDay.setBackgroundResource(android.R.drawable.btn_default_small);
                        tvDay.setBackgroundTintList(android.content.res.ColorStateList.valueOf(android.graphics.Color.parseColor("#FF9800")));
                        tvDay.setTextColor(android.graphics.Color.WHITE);
                        tvDay.setTypeface(null, android.graphics.Typeface.BOLD);
                    } else if (currentDay > today) {
                        tvDay.setTextColor(android.graphics.Color.parseColor("#CCCCCC"));
                    } else {
                        tvDay.setTextColor(android.graphics.Color.parseColor("#333333"));
                    }
                    currentDay++;
                }
                dayRow.addView(tvDay);
            }
            calContainer.addView(dayRow);
            if (currentDay > maxDays) break;
        }
        cardCal.addView(calContainer);
        return cardCal;
    }

    private CardView taoOThanhTuu(String tieuDe, String moTa, boolean daDatDuoc, String mauNen, String mauChu) {
        CardView card = new CardView(this);
        android.widget.LinearLayout.LayoutParams cardParams = new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        cardParams.setMargins(dpToPx(4), dpToPx(4), dpToPx(4), dpToPx(4));
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(12));
        card.setCardElevation(0);
        card.setCardBackgroundColor(android.graphics.Color.parseColor(daDatDuoc ? mauNen : "#F5F5F5"));
        android.widget.LinearLayout inner = new android.widget.LinearLayout(this);
        inner.setOrientation(android.widget.LinearLayout.VERTICAL);
        inner.setPadding(dpToPx(12), dpToPx(16), dpToPx(12), dpToPx(16));
        inner.setGravity(android.view.Gravity.CENTER);
        TextView tvTitle = new TextView(this);
        tvTitle.setText(tieuDe);
        tvTitle.setTextSize(13);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(android.graphics.Color.parseColor(daDatDuoc ? mauChu : "#9E9E9E"));
        inner.addView(tvTitle);
        TextView tvDesc = new TextView(this);
        tvDesc.setText(moTa);
        tvDesc.setTextSize(11);
        tvDesc.setTextColor(android.graphics.Color.parseColor(daDatDuoc ? mauChu : "#BDBDBD"));
        tvDesc.setPadding(0, dpToPx(4), 0, 0);
        inner.addView(tvDesc);
        card.addView(inner);
        return card;
    }

    private void hienThiMenuLoaiThoiGian() {
        com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = taoBottomSheetDialogChung("Chọn thời gian");
        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        android.widget.LinearLayout row1 = new android.widget.LinearLayout(this);
        row1.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        row1.setWeightSum(3);
        row1.addView(taoOChonThoiGian("Ngày", android.R.drawable.ic_menu_agenda, "#00BCD4", taoSuKienChon("Ngày", bottomSheetDialog)));
        row1.addView(taoOChonThoiGian("Tuần", android.R.drawable.ic_menu_recent_history, "#4CAF50", taoSuKienChon("Tuần", bottomSheetDialog)));
        row1.addView(taoOChonThoiGian("Tháng", android.R.drawable.ic_menu_myplaces, "#FF9800", taoSuKienChon("Tháng", bottomSheetDialog)));
        root.addView(row1);
        android.widget.LinearLayout row2 = new android.widget.LinearLayout(this);
        row2.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        row2.setWeightSum(3);
        row2.addView(taoOChonThoiGian("Năm", android.R.drawable.ic_menu_sort_by_size, "#9C27B0", taoSuKienChon("Năm", bottomSheetDialog)));
        row2.addView(taoOChonThoiGian("Tất cả", android.R.drawable.ic_menu_gallery, "#607D8B", taoSuKienChon("Mọi thời gian", bottomSheetDialog)));
        row2.addView(taoOChonThoiGian("Tùy chỉnh", android.R.drawable.ic_menu_edit, "#FF4B4B", taoSuKienChon("Tùy chỉnh", bottomSheetDialog)));
        root.addView(row2);
        hoanThienBottomSheet(bottomSheetDialog, root);
    }

    private View.OnClickListener taoSuKienChon(String option, com.google.android.material.bottomsheet.BottomSheetDialog dialog) {
        return v -> {
            cheDoThoiGian = option;
            tvLoaiThoiGian.setText(cheDoThoiGian + " ▼");
            if (cheDoThoiGian.equals("Mọi thời gian")) {
                cvChonNgayThang.setVisibility(View.GONE);
            } else {
                cvChonNgayThang.setVisibility(View.VISIBLE);
                capNhatTextThoiGianMacDinh();
                if(cheDoThoiGian.equals("Tùy chỉnh")) chonTuyChinh();
            }
            dialog.dismiss();
        };
    }

    private void capNhatTextThoiGianMacDinh() {
        Calendar c = Calendar.getInstance();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        switch (cheDoThoiGian) {
            case "Ngày":
                tvChonNgayThang.setText("Hôm nay, " + sdf.format(c.getTime()) + " ▼");
                break;
            case "Tuần":
                SimpleDateFormat sdfDay = new SimpleDateFormat("dd/MM", Locale.getDefault());
                Calendar calWeek = Calendar.getInstance();
                calWeek.setFirstDayOfWeek(Calendar.MONDAY);
                calWeek.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
                String startWeek = sdfDay.format(calWeek.getTime());
                calWeek.add(Calendar.DAY_OF_WEEK, 6);
                String endWeek = sdfDay.format(calWeek.getTime());
                tvChonNgayThang.setText(startWeek + " - " + endWeek + " ▼");
                break;
            case "Tháng":
                tvChonNgayThang.setText("tháng " + (c.get(Calendar.MONTH) + 1) + " năm " + c.get(Calendar.YEAR) + " ▼");
                break;
            case "Năm":
                tvChonNgayThang.setText("Năm " + c.get(Calendar.YEAR) + " ▼");
                break;
            case "Tùy chỉnh":
                tvChonNgayThang.setText("Chưa chọn phạm vi ▼");
                break;
        }
    }

    private void xuLyChonThoiGianChiTiet() {
        switch (cheDoThoiGian) {
            case "Ngày": chonNgayTrenLich(); break;
            case "Tuần": chonTuan(); break;
            case "Tháng": chonThang(); break;
            case "Năm": chonNam(); break;
            case "Tùy chỉnh": chonTuyChinh(); break;
        }
    }

    private void chonNgayTrenLich() {
        Calendar c = Calendar.getInstance();
        new DatePickerDialog(this, (view, year, month, dayOfMonth) -> {
            tvChonNgayThang.setText("Ngày " + dayOfMonth + "/" + (month + 1) + "/" + year + " ▼");
        }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show();
    }

    private void chonTuan() {
        com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = taoBottomSheetDialogChung("Chọn tuần");
        android.widget.LinearLayout listContainer = new android.widget.LinearLayout(this);
        listContainer.setOrientation(android.widget.LinearLayout.VERTICAL);
        String textHienTai = tvChonNgayThang.getText().toString().replace(" ▼", "");
        SimpleDateFormat sdfDay = new SimpleDateFormat("dd/MM", Locale.getDefault());
        SimpleDateFormat sdfYear = new SimpleDateFormat("yyyy", Locale.getDefault());
        Calendar cal = Calendar.getInstance();
        cal.setFirstDayOfWeek(Calendar.MONDAY);
        cal.add(Calendar.WEEK_OF_YEAR, -3);
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        for (int i = 0; i < 5; i++) {
            String ngayBatDau = sdfDay.format(cal.getTime());
            String nam = sdfYear.format(cal.getTime());
            cal.add(Calendar.DAY_OF_WEEK, 6);
            String chuoiHienThi = ngayBatDau + " - " + sdfDay.format(cal.getTime());
            boolean isSelected = textHienTai.equals(chuoiHienThi);
            View.OnClickListener listener = v -> { tvChonNgayThang.setText(chuoiHienThi + " ▼"); bottomSheetDialog.dismiss(); };
            listContainer.addView(taoOThoiGianChiTiet(chuoiHienThi, "Năm " + nam, android.R.drawable.ic_menu_recent_history, isSelected, listener));
            cal.add(Calendar.DAY_OF_WEEK, 1);
        }
        hoanThienBottomSheet(bottomSheetDialog, listContainer);
    }

    private void chonThang() {
        com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = taoBottomSheetDialogChung("Chọn tháng");
        android.widget.LinearLayout listContainer = new android.widget.LinearLayout(this);
        listContainer.setOrientation(android.widget.LinearLayout.VERTICAL);
        String textHienTai = tvChonNgayThang.getText().toString().replace(" ▼", "");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -2);
        for (int i = 0; i < 5; i++) {
            int thang = cal.get(Calendar.MONTH) + 1;
            int nam = cal.get(Calendar.YEAR);
            String chuoiHienThi = "tháng " + thang + " năm " + nam;
            boolean isSelected = textHienTai.equals(chuoiHienThi);
            View.OnClickListener listener = v -> { tvChonNgayThang.setText(chuoiHienThi + " ▼"); bottomSheetDialog.dismiss(); };
            listContainer.addView(taoOThoiGianChiTiet("Tháng " + thang, "Năm " + nam, android.R.drawable.ic_menu_myplaces, isSelected, listener));
            cal.add(Calendar.MONTH, 1);
        }
        hoanThienBottomSheet(bottomSheetDialog, listContainer);
    }

    private void chonNam() {
        com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = taoBottomSheetDialogChung("Chọn năm");
        android.widget.LinearLayout listContainer = new android.widget.LinearLayout(this);
        listContainer.setOrientation(android.widget.LinearLayout.VERTICAL);
        String textHienTai = tvChonNgayThang.getText().toString().replace(" ▼", "");
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.YEAR, -2);
        for (int i = 0; i < 5; i++) {
            String chuoiHienThi = "Năm " + cal.get(Calendar.YEAR);
            boolean isSelected = textHienTai.equals(chuoiHienThi);
            View.OnClickListener listener = v -> { tvChonNgayThang.setText(chuoiHienThi + " ▼"); bottomSheetDialog.dismiss(); };
            listContainer.addView(taoOThoiGianChiTiet(chuoiHienThi, "", android.R.drawable.ic_menu_sort_by_size, isSelected, listener));
            cal.add(Calendar.YEAR, 1);
        }
        hoanThienBottomSheet(bottomSheetDialog, listContainer);
    }

    private void chonTuyChinh() {
        com.google.android.material.bottomsheet.BottomSheetDialog bottomSheetDialog = taoBottomSheetDialogChung("Tùy chỉnh thời gian");
        android.widget.LinearLayout listContainer = new android.widget.LinearLayout(this);
        listContainer.setOrientation(android.widget.LinearLayout.VERTICAL);
        String textHienTai = tvChonNgayThang.getText().toString().replace(" ▼", "");
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
        Calendar cal = Calendar.getInstance();
        String today = sdf.format(cal.getTime());
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
        String tuanNayStart = sdf.format(cal.getTime());
        cal.add(Calendar.DAY_OF_WEEK, 6);
        String subTuanNay = tuanNayStart + " - " + sdf.format(cal.getTime());
        cal = Calendar.getInstance();
        cal.set(Calendar.DAY_OF_MONTH, 1);
        String thangNayStart = sdf.format(cal.getTime());
        cal.add(Calendar.MONTH, 1);
        cal.add(Calendar.DAY_OF_MONTH, -1);
        String subThangNay = thangNayStart + " - " + sdf.format(cal.getTime());
        cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -30);
        String sub30Ngay = sdf.format(cal.getTime()) + " - " + today;
        cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_YEAR, -90);
        String sub90Ngay = sdf.format(cal.getTime()) + " - " + today;
        String[] titles = {"Tuần này", "Tháng này", "30 ngày trước", "90 ngày trước", "Chọn khoảng ngày..."};
        String[] subtitles = {subTuanNay, subThangNay, sub30Ngay, sub90Ngay, "Mở lịch tự do"};
        int[] icons = { android.R.drawable.ic_menu_agenda, android.R.drawable.ic_menu_myplaces, android.R.drawable.ic_menu_recent_history, android.R.drawable.ic_menu_recent_history, android.R.drawable.ic_menu_edit };
        for (int i = 0; i < titles.length; i++) {
            String title = titles[i];
            String subtitle = subtitles[i];
            boolean isSelected = textHienTai.equals(title);
            if (i == 4 && textHienTai.contains("→")) {
                isSelected = true; subtitle = textHienTai;
            }
            View.OnClickListener listener = v -> {
                bottomSheetDialog.dismiss();
                if (title.equals("Chọn khoảng ngày...")) moTrinhChonKhoangNgay();
                else tvChonNgayThang.setText(title + " ▼");
            };
            listContainer.addView(taoOThoiGianChiTiet(title, subtitle, icons[i], isSelected, listener));
        }
        hoanThienBottomSheet(bottomSheetDialog, listContainer);
    }

    private void moTrinhChonKhoangNgay() {
        MaterialDatePicker.Builder<Pair<Long, Long>> builder = MaterialDatePicker.Builder.dateRangePicker();
        builder.setTitleText("CHỌN PHẠM VI THỜI GIAN");
        MaterialDatePicker<Pair<Long, Long>> datePicker = builder.build();
        datePicker.addOnPositiveButtonClickListener(selection -> {
            SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy", Locale.getDefault());
            sdf.setTimeZone(TimeZone.getTimeZone("UTC"));
            tvChonNgayThang.setText(sdf.format(selection.first) + " → " + sdf.format(selection.second) + " ▼");
        });
        datePicker.show(getSupportFragmentManager(), "DATE_PICKER");
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    private com.google.android.material.bottomsheet.BottomSheetDialog taoBottomSheetDialogChung(String titleText) {
        com.google.android.material.bottomsheet.BottomSheetDialog dialog = new com.google.android.material.bottomsheet.BottomSheetDialog(this);
        android.widget.LinearLayout container = new android.widget.LinearLayout(this);
        container.setOrientation(android.widget.LinearLayout.VERTICAL);
        container.setBackgroundColor(android.graphics.Color.WHITE);
        container.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(24));
        container.setId(View.generateViewId());
        View handle = new View(this);
        handle.setBackgroundColor(android.graphics.Color.parseColor("#E0E0E0"));
        android.widget.LinearLayout.LayoutParams handleParams = new android.widget.LinearLayout.LayoutParams(dpToPx(40), dpToPx(5));
        handleParams.gravity = android.view.Gravity.CENTER_HORIZONTAL;
        handleParams.bottomMargin = dpToPx(16);
        container.addView(handle, handleParams);
        TextView tvTitle = new TextView(this);
        tvTitle.setText(titleText);
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(android.graphics.Color.BLACK);
        tvTitle.setGravity(android.view.Gravity.CENTER);
        android.widget.LinearLayout.LayoutParams titleParams = new android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        titleParams.bottomMargin = dpToPx(16);
        container.addView(tvTitle, titleParams);
        dialog.setContentView(container);
        return dialog;
    }

    private void hoanThienBottomSheet(com.google.android.material.bottomsheet.BottomSheetDialog dialog, android.view.View content) {
        android.widget.ScrollView scrollView = new android.widget.ScrollView(this);
        scrollView.addView(content);
        dialog.setContentView(scrollView);
        if (dialog.getWindow() != null) dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
        dialog.show();
    }

    private CardView taoOChonThoiGian(String tieuDe, int iconRes, String maMauHex, View.OnClickListener listener) {
        CardView card = new CardView(this);
        android.widget.LinearLayout.LayoutParams cardParams = new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f);
        cardParams.setMargins(dpToPx(6), dpToPx(6), dpToPx(6), dpToPx(6));
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(16));
        card.setCardElevation(0);
        card.setCardBackgroundColor(android.graphics.Color.parseColor("#F8F9FA"));
        android.util.TypedValue outValue = new android.util.TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
        card.setForeground(getDrawable(outValue.resourceId));
        card.setClickable(true);
        card.setOnClickListener(listener);
        android.widget.LinearLayout innerLayout = new android.widget.LinearLayout(this);
        innerLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
        innerLayout.setGravity(android.view.Gravity.CENTER);
        innerLayout.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(android.graphics.Color.parseColor(maMauHex));
        innerLayout.addView(icon, new android.widget.LinearLayout.LayoutParams(dpToPx(28), dpToPx(28)));
        TextView text = new TextView(this);
        text.setText(tieuDe);
        text.setTextSize(14);
        text.setTypeface(null, android.graphics.Typeface.BOLD);
        text.setTextColor(android.graphics.Color.parseColor("#333333"));
        android.widget.LinearLayout.LayoutParams textParams = new android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        textParams.topMargin = dpToPx(8);
        innerLayout.addView(text, textParams);
        card.addView(innerLayout);
        return card;
    }

    private CardView taoOThoiGianChiTiet(String tieuDeChinh, String tieuDePhu, int iconRes, boolean isSelected, View.OnClickListener listener) {
        CardView card = new CardView(this);
        android.widget.LinearLayout.LayoutParams cardParams = new android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dpToPx(8));
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(12));
        card.setCardElevation(0);
        card.setCardBackgroundColor(android.graphics.Color.parseColor(isSelected ? "#E0F7FA" : "#F8F9FA"));
        android.util.TypedValue outValue = new android.util.TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
        card.setForeground(getDrawable(outValue.resourceId));
        card.setClickable(true);
        card.setOnClickListener(listener);
        android.widget.LinearLayout inner = new android.widget.LinearLayout(this);
        inner.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        inner.setPadding(dpToPx(16), dpToPx(12), dpToPx(16), dpToPx(12));
        inner.setGravity(android.view.Gravity.CENTER_VERTICAL);
        android.widget.LinearLayout leftCol = new android.widget.LinearLayout(this);
        leftCol.setOrientation(android.widget.LinearLayout.VERTICAL);
        leftCol.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));
        android.widget.LinearLayout titleRow = new android.widget.LinearLayout(this);
        titleRow.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        titleRow.setGravity(android.view.Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        icon.setImageResource(iconRes);
        icon.setColorFilter(android.graphics.Color.parseColor(isSelected ? "#00BCD4" : "#888888"));
        titleRow.addView(icon, new android.widget.LinearLayout.LayoutParams(dpToPx(18), dpToPx(18)));
        TextView tvChinh = new TextView(this);
        tvChinh.setText("  " + tieuDeChinh);
        tvChinh.setTextSize(16);
        tvChinh.setTypeface(null, android.graphics.Typeface.BOLD);
        tvChinh.setTextColor(android.graphics.Color.parseColor(isSelected ? "#00BCD4" : "#333333"));
        titleRow.addView(tvChinh);
        leftCol.addView(titleRow);
        if (tieuDePhu != null && !tieuDePhu.isEmpty()) {
            TextView tvPhu = new TextView(this);
            tvPhu.setText(tieuDePhu);
            tvPhu.setTextSize(13);
            tvPhu.setTextColor(android.graphics.Color.parseColor("#888888"));
            tvPhu.setPadding(dpToPx(24), dpToPx(2), 0, 0);
            leftCol.addView(tvPhu);
        }
        inner.addView(leftCol);
        if (isSelected) {
            TextView tvCheck = new TextView(this);
            tvCheck.setText("✔");
            tvCheck.setTextSize(20);
            tvCheck.setTypeface(null, android.graphics.Typeface.BOLD);
            tvCheck.setTextColor(android.graphics.Color.parseColor("#00BCD4"));
            inner.addView(tvCheck);
        }
        card.addView(inner);
        return card;
    }
}