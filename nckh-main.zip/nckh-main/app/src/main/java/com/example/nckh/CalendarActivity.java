package com.example.nckh;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.text.DecimalFormat;
import java.util.Calendar;

public class CalendarActivity extends AppCompatActivity {

    private TextView tvNgayChon, tvTongThu, tvTongChi, tvSoDuNgay;
    private android.widget.LinearLayout llDanhSachGiaoDich;
    private DatabaseHelper dbHelper;

    // --- ĐÃ THÊM: Biến lưu ngày tháng năm đang chọn trên lịch ---
    private int currentDay;
    private int currentMonth;
    private int currentYear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        dbHelper = new DatabaseHelper(this);

        // Tạo giao diện bằng code
        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setBackgroundColor(android.graphics.Color.parseColor("#F5F7FA"));

        // Header
        CardView header = new CardView(this);
        header.setCardElevation(dpToPx(4));
        header.setCardBackgroundColor(android.graphics.Color.WHITE);
        android.widget.RelativeLayout headerLayout = new android.widget.RelativeLayout(this);
        headerLayout.setPadding(dpToPx(16), dpToPx(48), dpToPx(16), dpToPx(16)); // Padding top 48 tránh status bar
        headerLayout.setLayoutParams(new android.view.ViewGroup.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT));

        ImageView btnBack = new ImageView(this);
        btnBack.setImageResource(android.R.drawable.ic_menu_revert); // Có thể đổi thành icon back của bạn
        btnBack.setColorFilter(android.graphics.Color.parseColor("#333333"));
        android.widget.RelativeLayout.LayoutParams backParams = new android.widget.RelativeLayout.LayoutParams(dpToPx(32), dpToPx(32));
        backParams.addRule(android.widget.RelativeLayout.CENTER_VERTICAL);
        headerLayout.addView(btnBack, backParams);
        btnBack.setOnClickListener(v -> finish());

        TextView tvTitle = new TextView(this);
        tvTitle.setText("Giao dịch theo ngày");
        tvTitle.setTextSize(20);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(android.graphics.Color.parseColor("#333333"));
        android.widget.RelativeLayout.LayoutParams titleParams = new android.widget.RelativeLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
        titleParams.addRule(android.widget.RelativeLayout.CENTER_IN_PARENT);
        headerLayout.addView(tvTitle, titleParams);
        header.addView(headerLayout);
        root.addView(header);

        // Body cuộn được
        android.widget.ScrollView scrollView = new android.widget.ScrollView(this);
        scrollView.setLayoutParams(new android.widget.LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT));
        scrollView.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        scrollView.setClipToPadding(false);

        android.widget.LinearLayout body = new android.widget.LinearLayout(this);
        body.setOrientation(android.widget.LinearLayout.VERTICAL);

        // 1. Lịch
        CardView calCard = new CardView(this);
        calCard.setRadius(dpToPx(16));
        calCard.setCardElevation(dpToPx(2));
        calCard.setCardBackgroundColor(android.graphics.Color.WHITE);
        android.widget.LinearLayout.LayoutParams calParams = new android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        calParams.bottomMargin = dpToPx(16);
        calCard.setLayoutParams(calParams);
        CalendarView calendarView = new CalendarView(this);
        calCard.addView(calendarView);
        body.addView(calCard);

        tvNgayChon = new TextView(this);
        tvNgayChon.setTextSize(14);
        tvNgayChon.setTextColor(android.graphics.Color.parseColor("#888888"));
        tvNgayChon.setPadding(dpToPx(4), 0, 0, dpToPx(8));
        body.addView(tvNgayChon);

        // 2. Thẻ Tổng Quan
        CardView detailCard = new CardView(this);
        detailCard.setRadius(dpToPx(16));
        detailCard.setCardElevation(dpToPx(2));
        detailCard.setCardBackgroundColor(android.graphics.Color.WHITE);
        detailCard.setLayoutParams(new android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));

        android.widget.LinearLayout detailLayout = new android.widget.LinearLayout(this);
        detailLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        detailLayout.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        detailLayout.setGravity(android.view.Gravity.CENTER);

        tvTongChi = new TextView(this);
        tvTongChi.setTextColor(android.graphics.Color.parseColor("#FF4B4B"));
        tvTongChi.setTextSize(14);
        tvTongChi.setTypeface(null, android.graphics.Typeface.BOLD);
        detailLayout.addView(tvTongChi);

        TextView tvSpace1 = new TextView(this); tvSpace1.setText("   "); detailLayout.addView(tvSpace1);

        tvTongThu = new TextView(this);
        tvTongThu.setTextColor(android.graphics.Color.parseColor("#009688"));
        tvTongThu.setTextSize(14);
        tvTongThu.setTypeface(null, android.graphics.Typeface.BOLD);
        detailLayout.addView(tvTongThu);

        TextView tvSpace2 = new TextView(this); tvSpace2.setText("   =   ");
        tvSpace2.setTypeface(null, android.graphics.Typeface.BOLD);
        detailLayout.addView(tvSpace2);

        tvSoDuNgay = new TextView(this);
        tvSoDuNgay.setTextColor(android.graphics.Color.parseColor("#333333"));
        tvSoDuNgay.setTextSize(15);
        tvSoDuNgay.setTypeface(null, android.graphics.Typeface.BOLD);
        detailLayout.addView(tvSoDuNgay);

        detailCard.addView(detailLayout);
        body.addView(detailCard);

        // 3. Danh sách Giao Dịch
        llDanhSachGiaoDich = new android.widget.LinearLayout(this);
        llDanhSachGiaoDich.setOrientation(android.widget.LinearLayout.VERTICAL);
        android.widget.LinearLayout.LayoutParams listParams = new android.widget.LinearLayout.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.WRAP_CONTENT);
        listParams.topMargin = dpToPx(16);
        llDanhSachGiaoDich.setLayoutParams(listParams);
        body.addView(llDanhSachGiaoDich);

        scrollView.addView(body);
        root.addView(scrollView);

        setContentView(root);

        // --- ĐÃ SỬA: Khởi tạo ngày mặc định là ngày hôm nay ---
        Calendar today = Calendar.getInstance();
        currentDay = today.get(Calendar.DAY_OF_MONTH);
        currentMonth = today.get(Calendar.MONTH);
        currentYear = today.get(Calendar.YEAR);

        // GỌI DỮ LIỆU KHI CHỌN LỊCH
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // Lưu lại ngày đang chọn
            currentDay = dayOfMonth;
            currentMonth = month;
            currentYear = year;
            capNhatDuLieuNgay(currentDay, currentMonth, currentYear);
        });
    }

    // --- ĐÃ THÊM: Hàm này tự động chạy khi màn hình hiển thị lại (VD: từ màn hình thêm giao dịch quay về) ---
    @Override
    protected void onResume() {
        super.onResume();
        // Load lại dữ liệu của ngày đang được chọn trên lịch để update số dư & danh sách
        capNhatDuLieuNgay(currentDay, currentMonth, currentYear);
    }

    private void capNhatDuLieuNgay(int day, int month, int year) {
        // Cộng 1 cho tháng để khớp với giá trị lưu trong Database
        int thangThucTe = month + 1;

        // Xử lý hiển thị "Thứ mấy, ngày mấy"
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day);
        int thu = cal.get(Calendar.DAY_OF_WEEK);
        String[] tenThu = {"", "CN", "Th 2", "Th 3", "Th 4", "Th 5", "Th 6", "Th 7"};
        tvNgayChon.setText(tenThu[thu] + ", " + day + " thg " + thangThucTe + ", " + year);

        // Xóa danh sách giao dịch cũ
        llDanhSachGiaoDich.removeAllViews();

        // 1. LẤY TỔNG TIỀN THEO NGÀY
        long tongThu = dbHelper.layTongTienTheoNgayVaLoai(day, thangThucTe, year, 1);
        long tongChi = dbHelper.layTongTienTheoNgayVaLoai(day, thangThucTe, year, 2);
        long soDu = tongThu - tongChi;

        DecimalFormat formatter = new DecimalFormat("#,###");

        tvTongChi.setText("▼ " + formatter.format(tongChi).replace(",", ".") + "đ");
        tvTongThu.setText("▲ " + formatter.format(tongThu).replace(",", ".") + "đ");
        tvSoDuNgay.setText(formatter.format(soDu).replace(",", ".") + "đ");

        // 2. LẤY CHI TIẾT CÁC GIAO DỊCH CỦA NGÀY
        Cursor cursor = dbHelper.layDanhSachGiaoDichTheoNgay(day, thangThucTe, year);
        boolean hasData = false;

        if (cursor != null) {
            while (cursor.moveToNext()) {
                hasData = true;
                long soTien = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_SO_TIEN));
                String danhMuc = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DANH_MUC));
                String ghiChu = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_GHI_CHU));
                int loai = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LOAI_GIAO_DICH));

                String formattedTien = formatter.format(soTien).replace(",", ".");
                veGiaoDichLenManHinh(formattedTien, danhMuc, ghiChu, loai);
            }
            cursor.close();
        }

        if (!hasData) {
            TextView tvRong = new TextView(this);
            tvRong.setText("Không có giao dịch nào trong ngày này.");
            tvRong.setGravity(android.view.Gravity.CENTER);
            tvRong.setPadding(0, dpToPx(32), 0, 0);
            tvRong.setTextColor(android.graphics.Color.parseColor("#888888"));
            llDanhSachGiaoDich.addView(tvRong);
        }
    }

    private void veGiaoDichLenManHinh(String soTien, String danhMuc, String ghiChu, int loaiGiaoDich) {
        CardView card = new CardView(this);
        android.widget.LinearLayout.LayoutParams cardParams = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dpToPx(12));
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(16));
        card.setCardElevation(0);
        card.setCardBackgroundColor(android.graphics.Color.WHITE);

        android.widget.LinearLayout inner = new android.widget.LinearLayout(this);
        inner.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        inner.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        inner.setGravity(android.view.Gravity.CENTER_VERTICAL);

        // Icon
        CardView iconBg = new CardView(this);
        iconBg.setRadius(dpToPx(24));
        iconBg.setCardElevation(0);
        iconBg.setCardBackgroundColor(android.graphics.Color.parseColor(loaiGiaoDich == 1 ? "#E8F5E9" : "#FFEBEE"));
        android.widget.LinearLayout.LayoutParams iconBgParams = new android.widget.LinearLayout.LayoutParams(dpToPx(48), dpToPx(48));
        iconBgParams.setMarginEnd(dpToPx(16));
        iconBg.setLayoutParams(iconBgParams);

        ImageView icon = new ImageView(this);
        icon.setImageResource(loaiGiaoDich == 1 ? android.R.drawable.ic_input_add : android.R.drawable.ic_menu_agenda);
        icon.setColorFilter(android.graphics.Color.parseColor(loaiGiaoDich == 1 ? "#4CAF50" : "#FF4B4B"));
        icon.setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12));
        iconBg.addView(icon);
        inner.addView(iconBg);

        // Chi tiết
        android.widget.LinearLayout textCol = new android.widget.LinearLayout(this);
        textCol.setOrientation(android.widget.LinearLayout.VERTICAL);
        textCol.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

        TextView tvCat = new TextView(this);
        tvCat.setText(danhMuc == null || danhMuc.isEmpty() ? (loaiGiaoDich == 1 ? "Thu nhập" : "Chi tiêu") : danhMuc);
        tvCat.setTextSize(16);
        tvCat.setTypeface(null, android.graphics.Typeface.BOLD);
        tvCat.setTextColor(android.graphics.Color.parseColor("#333333"));
        textCol.addView(tvCat);

        if (ghiChu != null && !ghiChu.isEmpty()) {
            TextView tvNote = new TextView(this);
            tvNote.setText(ghiChu);
            tvNote.setTextSize(13);
            tvNote.setTextColor(android.graphics.Color.parseColor("#888888"));
            tvNote.setPadding(0, dpToPx(2), 0, 0);
            textCol.addView(tvNote);
        }
        inner.addView(textCol);

        // Số tiền
        TextView tvAmt = new TextView(this);
        String prefix = (loaiGiaoDich == 1) ? "▲ " : "▼ ";
        String colorHex = (loaiGiaoDich == 1) ? "#009688" : "#FF4B4B";

        tvAmt.setText(prefix + soTien + "đ");
        tvAmt.setTextSize(15);
        tvAmt.setTypeface(null, android.graphics.Typeface.BOLD);
        tvAmt.setTextColor(android.graphics.Color.parseColor(colorHex));
        inner.addView(tvAmt);

        card.addView(inner);
        llDanhSachGiaoDich.addView(card);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}