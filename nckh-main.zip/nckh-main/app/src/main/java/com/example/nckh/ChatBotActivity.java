package com.example.nckh;

import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ChatBotActivity extends AppCompatActivity {

    private RecyclerView rvChat;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> chatList;

    private EditText edtChatInput;
    private ImageView btnSend, btnMic, btnCamera, btnBack;

    private DatabaseHelper dbHelper;
    private Map<String, String> tuDienThuNhap;
    private Map<String, String> tuDienChiPhi;

    // TODO: Điền API Key của Google Gemini vào đây (Lấy tại aistudio.google.com)
    private static final String GEMINI_API_KEY = "AIzaSyD4buciRrXsqf-VPWX5wPYFsR4_RBjogOc";

    private final ExecutorService executorService = Executors.newSingleThreadExecutor();
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_bot);

        dbHelper = new DatabaseHelper(this);
        khoiTaoTuDien();
        initUI();
    }

    private void initUI() {
        rvChat = findViewById(R.id.rvChat);
        edtChatInput = findViewById(R.id.edtChatInput);
        btnSend = findViewById(R.id.btnSend);
        btnMic = findViewById(R.id.btnMic);
        btnCamera = findViewById(R.id.btnCamera);
        btnBack = findViewById(R.id.btnBack);

        chatList = new ArrayList<>();
        chatAdapter = new ChatAdapter(chatList);
        rvChat.setLayoutManager(new LinearLayoutManager(this));
        rvChat.setAdapter(chatAdapter);

        // Tin nhắn chào mừng
        addBotMessage(ChatMessage.TYPE_BOT_TEXT, "Xin chào! 👋 Hãy kể cho mình bạn vừa thu chi gì nhé (VD: Mình vừa ăn sáng 35k và đổ xăng 50k)", null);

        // Bắt sự kiện
        btnBack.setOnClickListener(v -> finish());
        btnSend.setOnClickListener(v -> handleUserSendMessage());
        btnMic.setOnClickListener(v -> Toast.makeText(this, "Voice-to-Text: Đang lắng nghe...", Toast.LENGTH_SHORT).show());
        btnCamera.setOnClickListener(v -> Toast.makeText(this, "OCR: Mở Camera quét hóa đơn...", Toast.LENGTH_SHORT).show());
    }

    private void handleUserSendMessage() {
        String input = edtChatInput.getText().toString().trim();
        if (input.isEmpty()) return;

        addUserMessage(input);
        edtChatInput.setText("");

        // Vô hiệu hóa nút gửi trong lúc chờ AI
        btnSend.setEnabled(false);
        addBotMessage(ChatMessage.TYPE_BOT_TEXT, "Đang phân tích dữ liệu...", null);

        processAILogic(input);
    }


    private void processAILogic(String input) {
        executorService.execute(() -> {
            try {

                String prompt = "Phân tích câu sau và trích xuất các giao dịch tài chính. Trả về DUY NHẤT một mảng JSON, không có text nào khác. " +
                        "Mỗi object trong mảng có cấu trúc: " +
                        "{\"soTien\": (số nguyên, k=1000, tr=1000000), " +
                        "\"loaiGiaoDich\": (1 nếu là thu, 2 nếu là chi), " +
                        "\"danhMuc\": (chuỗi ngắn gọn: Thức ăn & Đồ uống, Di chuyển, Mua sắm, Tiền lương...), " +
                        "\"ghiChu\": (mô tả chi tiết từ câu nói)}.\n" +
                        "Câu nói: \"" + input + "\"";

                URL url = new URL("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + GEMINI_API_KEY);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                // Body request
                JSONObject part = new JSONObject();
                part.put("text", prompt);
                JSONArray parts = new JSONArray();
                parts.put(part);
                JSONObject content = new JSONObject();
                content.put("parts", parts);
                JSONArray contents = new JSONArray();
                contents.put(content);
                JSONObject body = new JSONObject();
                body.put("contents", contents);

                OutputStream os = conn.getOutputStream();
                os.write(body.toString().getBytes("UTF-8"));
                os.flush();
                os.close();

                // Đọc response
                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), "UTF-8"));
                StringBuilder response = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) response.append(line);
                br.close();

                // Parse JSON trả về từ AI
                JSONObject jsonResponse = new JSONObject(response.toString());
                String aiText = jsonResponse.getJSONArray("candidates")
                        .getJSONObject(0).getJSONObject("content")
                        .getJSONArray("parts").getJSONObject(0)
                        .getString("text");

                // Làm sạch chuỗi JSON (xóa ```json và ``` nếu có)
                aiText = aiText.replaceAll("(?s)```json\\n?(.*?)\\n?```", "$1").trim();

                JSONArray jsonArray = new JSONArray(aiText);
                List<TransactionData> extractedTransactions = new ArrayList<>();
                StringBuilder botAdvice = new StringBuilder();

                for (int i = 0; i < jsonArray.length(); i++) {
                    JSONObject obj = jsonArray.getJSONObject(i);
                    TransactionData data = new TransactionData();
                    data.soTien = obj.getLong("soTien");
                    data.loaiGiaoDich = obj.getInt("loaiGiaoDich");
                    data.danhMuc = obj.getString("danhMuc");
                    data.ghiChu = obj.getString("ghiChu");

                    extractedTransactions.add(data);
                    luuVaoDatabase(data);
                    botAdvice.append(generateAdvice(data)).append(" ");
                }

                // Cập nhật UI
                mainHandler.post(() -> updateUIWithResults(extractedTransactions, botAdvice.toString()));

            } catch (Exception e) {
                Log.e("ChatBotActivity", "AI Error: " + e.getMessage());
                // Nếu gọi AI lỗi (mất mạng, hết quota...), quay về dùng Regex thủ công
                mainHandler.post(() -> processFallbackLogic(input));
            }
        });
    }

    private void updateUIWithResults(List<TransactionData> extractedTransactions, String advice) {
        btnSend.setEnabled(true);
        // Xóa tin nhắn "Đang phân tích..."
        chatList.remove(chatList.size() - 1);
        chatAdapter.notifyItemRemoved(chatList.size());

        if (!extractedTransactions.isEmpty()) {
            addBotMessage(ChatMessage.TYPE_BOT_TEXT, advice.trim(), null);
            for (TransactionData tx : extractedTransactions) {
                addBotMessage(ChatMessage.TYPE_BOT_TRANSACTION, null, tx);
            }
        } else {
            addBotMessage(ChatMessage.TYPE_BOT_TEXT, "Mình chưa nhận diện được số tiền. Bạn nói rõ hơn nhé!", null);
        }
    }

    // ==========================================
    // LOGIC CŨ (Dùng làm Fallback nếu AI lỗi)
    // ==========================================
    private void processFallbackLogic(String input) {
        btnSend.setEnabled(true);
        chatList.remove(chatList.size() - 1); // Xóa chữ Đang phân tích...
        chatAdapter.notifyItemRemoved(chatList.size());

        String[] transactionParts = input.split(",|\\s+và\\s+");
        StringBuilder botAdvice = new StringBuilder();
        List<TransactionData> extractedTransactions = new ArrayList<>();

        for (String part : transactionParts) {
            TransactionData data = extractTransaction(part.trim());
            if (data != null && data.soTien > 0) {
                extractedTransactions.add(data);
                luuVaoDatabase(data);
                botAdvice.append(generateAdvice(data)).append(" ");
            }
        }
        updateUIWithResults(extractedTransactions, botAdvice.toString());
    }

    private TransactionData extractTransaction(String input) {
        TransactionData data = new TransactionData();
        data.ghiChu = input;
        data.loaiGiaoDich = 2;

        Pattern pattern = Pattern.compile("(\\d+)\\s*(k|tr|m|củ)?");
        Matcher matcher = pattern.matcher(input);

        if (matcher.find()) {
            try {
                long number = Long.parseLong(matcher.group(1));
                String donVi = matcher.group(2);
                if (donVi != null) {
                    if (donVi.equals("k")) data.soTien = number * 1000;
                    else if (donVi.equals("tr") || donVi.equals("m") || donVi.equals("củ")) data.soTien = number * 1000000;
                } else data.soTien = number;
                data.ghiChu = input.replaceFirst(matcher.group(0), "").trim();
            } catch (Exception e) { return null; }
        } else return null;

        boolean laThuNhap = false;
        for (Map.Entry<String, String> entry : tuDienThuNhap.entrySet()) {
            if (data.ghiChu.contains(entry.getKey())) {
                data.loaiGiaoDich = 1; data.danhMuc = entry.getValue(); laThuNhap = true; break;
            }
        }

        if (!laThuNhap) {
            for (Map.Entry<String, String> entry : tuDienChiPhi.entrySet()) {
                if (data.ghiChu.contains(entry.getKey())) { data.danhMuc = entry.getValue(); break; }
            }
        }

        if(data.ghiChu.isEmpty()) data.ghiChu = data.danhMuc;
        return data;
    }

    // ==========================================
    // CÁC HÀM TIỆN ÍCH GIỮ NGUYÊN
    // ==========================================
    private String generateAdvice(TransactionData data) {
        String formatTien = (data.soTien / 1000) + "k";
        if (data.danhMuc.equals("Thức ăn & Đồ uống")) {
            if (data.soTien <= 50000) return "Chi phí " + formatTien + " cho " + data.ghiChu + " là tương đối hợp lý.";
            else return "Bạn đã chi " + formatTien + " cho " + data.ghiChu + ". Để tiết kiệm hơn, có thể xem xét nấu ăn tại nhà nhé!";
        }
        return "Đã ghi nhận khoản " + (data.loaiGiaoDich == 1 ? "thu " : "chi ") + formatTien + " cho " + data.ghiChu + ".";
    }

    private void luuVaoDatabase(TransactionData data) {
        Calendar cal = Calendar.getInstance();
        data.ngay = cal.get(Calendar.DAY_OF_MONTH);
        data.thang = cal.get(Calendar.MONTH) + 1;
        data.nam = cal.get(Calendar.YEAR);

        dbHelper.themGiaoDich(data.soTien, data.loaiGiaoDich, data.danhMuc, data.ghiChu, data.ngay, data.thang, data.nam);
    }

    private void khoiTaoTuDien() {
        tuDienThuNhap = new HashMap<>();
        tuDienThuNhap.put("lương", "Tiền lương");
        tuDienThuNhap.put("thưởng", "Tiền thưởng");

        tuDienChiPhi = new HashMap<>();
        tuDienChiPhi.put("bữa tối", "Thức ăn & Đồ uống");
        tuDienChiPhi.put("mua sắm", "Mua sắm");
        tuDienChiPhi.put("xăng", "Di chuyển");
        tuDienChiPhi.put("cà phê", "Thức ăn & Đồ uống");
    }

    private void addUserMessage(String text) {
        chatList.add(new ChatMessage(ChatMessage.TYPE_USER, text, null));
        chatAdapter.notifyItemInserted(chatList.size() - 1);
        rvChat.scrollToPosition(chatList.size() - 1);
    }

    private void addBotMessage(int type, String text, TransactionData data) {
        chatList.add(new ChatMessage(type, text, data));
        chatAdapter.notifyItemInserted(chatList.size() - 1);
        rvChat.scrollToPosition(chatList.size() - 1);
    }

    // ==========================================
    // INNER CLASSES CHO RECYCLER VIEW
    // ==========================================
    public static class TransactionData {
        long soTien; int loaiGiaoDich; String danhMuc = "Khác", ghiChu; int ngay, thang, nam;
    }

    public static class ChatMessage {
        static final int TYPE_USER = 0, TYPE_BOT_TEXT = 1, TYPE_BOT_TRANSACTION = 2;
        int type; String textMessage; TransactionData transactionData;
        ChatMessage(int type, String text, TransactionData data) { this.type = type; this.textMessage = text; this.transactionData = data; }
    }

    public class ChatAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        private List<ChatMessage> messages;
        public ChatAdapter(List<ChatMessage> messages) { this.messages = messages; }

        @Override public int getItemViewType(int position) { return messages.get(position).type; }
        @Override public int getItemCount() { return messages.size(); }

        @NonNull @Override
        public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            LayoutInflater inflater = LayoutInflater.from(parent.getContext());
            if (viewType == ChatMessage.TYPE_USER) return new UserViewHolder(inflater.inflate(R.layout.item_chat_user, parent, false));
            else if (viewType == ChatMessage.TYPE_BOT_TEXT) return new BotTextViewHolder(inflater.inflate(R.layout.item_chat_bot_text, parent, false));
            else return new BotTransactionViewHolder(inflater.inflate(R.layout.item_chat_bot_transaction, parent, false));
        }

        @Override
        public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
            ChatMessage msg = messages.get(position);
            if (holder instanceof UserViewHolder) ((UserViewHolder) holder).tvText.setText(msg.textMessage);
            else if (holder instanceof BotTextViewHolder) ((BotTextViewHolder) holder).tvText.setText(msg.textMessage);
            else if (holder instanceof BotTransactionViewHolder) {
                BotTransactionViewHolder txHolder = (BotTransactionViewHolder) holder;
                TransactionData tx = msg.transactionData;

                txHolder.tvDanhMuc.setText(tx.danhMuc);
                txHolder.tvGhiChu.setText(tx.ghiChu);
                txHolder.tvSoTien.setText(new DecimalFormat("#,###đ").format(tx.soTien));
                txHolder.tvThoiGian.setText("Th " + tx.thang + ", " + tx.ngay + " thg " + tx.thang);

                txHolder.btnDiChuyenQuy.setOnClickListener(v -> Toast.makeText(ChatBotActivity.this, "Popup di chuyển quỹ", Toast.LENGTH_SHORT).show());
                txHolder.btnGiaoDichDinhKy.setOnClickListener(v -> Toast.makeText(ChatBotActivity.this, "Set định kỳ", Toast.LENGTH_SHORT).show());
            }
        }

        class UserViewHolder extends RecyclerView.ViewHolder { TextView tvText; UserViewHolder(View v) { super(v); tvText = v.findViewById(R.id.tvMessage); } }
        class BotTextViewHolder extends RecyclerView.ViewHolder { TextView tvText; BotTextViewHolder(View v) { super(v); tvText = v.findViewById(R.id.tvMessage); } }
        class BotTransactionViewHolder extends RecyclerView.ViewHolder {
            TextView tvDanhMuc, tvGhiChu, tvSoTien, tvThoiGian; View btnDiChuyenQuy, btnGiaoDichDinhKy;
            BotTransactionViewHolder(View v) {
                super(v);
                tvDanhMuc = v.findViewById(R.id.tvDanhMuc); tvGhiChu = v.findViewById(R.id.tvGhiChu);
                tvSoTien = v.findViewById(R.id.tvSoTien); tvThoiGian = v.findViewById(R.id.tvThoiGian);
                btnDiChuyenQuy = v.findViewById(R.id.btnDiChuyenQuy); btnGiaoDichDinhKy = v.findViewById(R.id.btnGiaoDichDinhKy);
            }
        }
    }
}