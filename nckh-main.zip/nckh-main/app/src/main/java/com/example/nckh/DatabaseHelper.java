package com.example.nckh;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "QuanLyChiTieu.db";
    private static final int DATABASE_VERSION = 2;

    public static final String TABLE_GIAO_DICH = "giao_dich";

    public static final String COLUMN_ID = "id";
    public static final String COLUMN_SO_TIEN = "so_tien";
    public static final String COLUMN_LOAI_GIAO_DICH = "loai_giao_dich"; // 1 = Thu, 2 = Chi
    public static final String COLUMN_DANH_MUC = "danh_muc";
    public static final String COLUMN_GHI_CHU = "ghi_chu";
    public static final String COLUMN_NGAY = "ngay";
    public static final String COLUMN_THANG = "thang";
    public static final String COLUMN_NAM = "nam";
    public static final String COLUMN_TIMESTAMP = "timestamp";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_TABLE_GIAO_DICH = "CREATE TABLE " + TABLE_GIAO_DICH + "("
                + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + COLUMN_SO_TIEN + " REAL,"
                + COLUMN_LOAI_GIAO_DICH + " INTEGER,"
                + COLUMN_DANH_MUC + " TEXT,"
                + COLUMN_GHI_CHU + " TEXT,"
                + COLUMN_NGAY + " INTEGER,"
                + COLUMN_THANG + " INTEGER,"
                + COLUMN_NAM + " INTEGER,"
                + COLUMN_TIMESTAMP + " INTEGER"
                + ")";
        db.execSQL(CREATE_TABLE_GIAO_DICH);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_GIAO_DICH);
        onCreate(db);
    }

    // ==========================================
    // 1. THÊM GIAO DỊCH
    // ==========================================
    public long themGiaoDich(long soTien, int loaiGiaoDich, String danhMuc, String ghiChu, int ngay, int thang, int nam) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_SO_TIEN, soTien);
        values.put(COLUMN_LOAI_GIAO_DICH, loaiGiaoDich);
        values.put(COLUMN_DANH_MUC, danhMuc);
        values.put(COLUMN_GHI_CHU, ghiChu);
        values.put(COLUMN_NGAY, ngay);
        values.put(COLUMN_THANG, thang);
        values.put(COLUMN_NAM, nam);
        values.put(COLUMN_TIMESTAMP, System.currentTimeMillis());

        long id = db.insert(TABLE_GIAO_DICH, null, values);
        db.close();
        return id;
    }

    // ==========================================
    // 2. CÁC HÀM DÙNG CHO MAIN ACTIVITY
    // ==========================================
    public Cursor layTatCaGiaoDich() {
        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_GIAO_DICH + " ORDER BY " + COLUMN_TIMESTAMP + " DESC", null);
    }

    public long layTongTienTheoLoai(int loaiGiaoDich) {
        SQLiteDatabase db = this.getReadableDatabase();
        long tongTien = 0;
        String query = "SELECT SUM(" + COLUMN_SO_TIEN + ") FROM " + TABLE_GIAO_DICH + " WHERE " + COLUMN_LOAI_GIAO_DICH + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(loaiGiaoDich)});
        if (cursor.moveToFirst() && cursor.getString(0) != null) {
            tongTien = cursor.getLong(0);
        }
        cursor.close();
        return tongTien;
    }

    // ==========================================
    // 3. CÁC HÀM DÙNG CHO CALENDAR ACTIVITY
    // ==========================================
    public Cursor layDanhSachGiaoDichTheoNgay(int ngay, int thang, int nam) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_GIAO_DICH +
                " WHERE " + COLUMN_NGAY + "=? AND " + COLUMN_THANG + "=? AND " + COLUMN_NAM + "=?" +
                " ORDER BY " + COLUMN_ID + " DESC";
        return db.rawQuery(query, new String[]{String.valueOf(ngay), String.valueOf(thang), String.valueOf(nam)});
    }

    public long layTongTienTheoNgayVaLoai(int ngay, int thang, int nam, int loaiGiaoDich) {
        SQLiteDatabase db = this.getReadableDatabase();
        long tong = 0;
        String query = "SELECT SUM(" + COLUMN_SO_TIEN + ") FROM " + TABLE_GIAO_DICH +
                " WHERE " + COLUMN_NGAY + "=? AND " + COLUMN_THANG + "=? AND " + COLUMN_NAM + "=? AND " + COLUMN_LOAI_GIAO_DICH + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(ngay), String.valueOf(thang), String.valueOf(nam), String.valueOf(loaiGiaoDich)});
        if (cursor.moveToFirst() && cursor.getString(0) != null) {
            tong = cursor.getLong(0);
        }
        cursor.close();
        return tong;
    }

    // ==========================================
    // 4. CÁC HÀM DÙNG CHO PHÂN TÍCH THÁNG
    // ==========================================
    public Cursor layGiaoDichTheoThang(int thang, int nam) {
        SQLiteDatabase db = this.getReadableDatabase();
        String query = "SELECT * FROM " + TABLE_GIAO_DICH +
                " WHERE " + COLUMN_THANG + "=? AND " + COLUMN_NAM + "=?" +
                " ORDER BY " + COLUMN_NGAY + " DESC, " + COLUMN_ID + " DESC";
        return db.rawQuery(query, new String[]{String.valueOf(thang), String.valueOf(nam)});
    }

    public long layTongTienThangVaLoai(int thang, int nam, int loaiGiaoDich) {
        SQLiteDatabase db = this.getReadableDatabase();
        long tong = 0;
        String query = "SELECT SUM(" + COLUMN_SO_TIEN + ") FROM " + TABLE_GIAO_DICH +
                " WHERE " + COLUMN_THANG + "=? AND " + COLUMN_NAM + "=? AND " + COLUMN_LOAI_GIAO_DICH + "=?";
        Cursor cursor = db.rawQuery(query, new String[]{String.valueOf(thang), String.valueOf(nam), String.valueOf(loaiGiaoDich)});
        if (cursor.moveToFirst() && cursor.getString(0) != null) {
            tong = cursor.getLong(0);
        }
        cursor.close();
        return tong;
    }
}