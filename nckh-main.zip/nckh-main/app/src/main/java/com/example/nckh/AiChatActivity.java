package com.example.nckh;

import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.widget.*;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

import okhttp3.*;

public class AiChatActivity extends AppCompatActivity {

    private LinearLayout chatContainer;
    private ScrollView scrollView;
    private EditText edtChat;
    private ImageView btnSend;

    // TODO: THAY API KEY CỦA BẠN VÀO ĐÂY
    private static final String GEMINI_API_KEY = "AIzaSyD4buciRrXsqf-VPWX5wPYFsR4_RBjogOc";

    private static final String GEMINI_URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=" + GEMINI_API_KEY;

    private OkHttpClient client;
    private boolean isCalling = false;
    private boolean isDestroyed = false;
    private Handler handler = new Handler(Looper.getMainLooper());
    private View currentThinkingView = null;
    private Thread typingThread = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        isDestroyed = false;

        client = new OkHttpClient.Builder()
                .connectTimeout(60, TimeUnit.SECONDS)
                .readTimeout(60, TimeUnit.SECONDS)
                .build();

        setupUI();
        addBotMessage("👋 Chào Bạn! Mình là trợ lý AI. Hôm nay mình có thể giúp gì cho bạn?");
    }

    private void setupUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.parseColor("#F5F5F5"));

        ViewCompat.setOnApplyWindowInsetsListener(root, (v, windowInsets) -> {
            Insets insets = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars() | WindowInsetsCompat.Type.ime());
            v.setPadding(insets.left, insets.top, insets.right, insets.bottom);
            return WindowInsetsCompat.CONSUMED;
        });

        TextView header = new TextView(this);
        header.setText("Gemini AI Assistant");
        header.setTextSize(18);
        header.setTypeface(Typeface.DEFAULT_BOLD);
        header.setTextColor(Color.WHITE);
        header.setBackgroundColor(Color.parseColor("#1B5E20"));
        header.setPadding(20, 40, 20, 40);
        header.setGravity(Gravity.CENTER);
        root.addView(header);

        scrollView = new ScrollView(this);
        scrollView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        chatContainer = new LinearLayout(this);
        chatContainer.setOrientation(LinearLayout.VERTICAL);
        chatContainer.setPadding(20, 20, 20, 20);
        scrollView.addView(chatContainer);
        root.addView(scrollView);

        LinearLayout bottom = new LinearLayout(this);
        bottom.setPadding(20, 20, 20, 20);
        bottom.setBackgroundColor(Color.WHITE);
        bottom.setGravity(Gravity.CENTER_VERTICAL);

        edtChat = new EditText(this);
        edtChat.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        edtChat.setHint("Nhập tin nhắn...");
        GradientDrawable edtBg = new GradientDrawable();
        edtBg.setCornerRadius(50);
        edtBg.setStroke(2, Color.parseColor("#E0E0E0"));
        edtBg.setColor(Color.parseColor("#FAFAFA"));
        edtChat.setBackground(edtBg);
        edtChat.setPadding(40, 25, 40, 25);
        bottom.addView(edtChat);

        btnSend = new ImageView(this);
        btnSend.setImageResource(android.R.drawable.ic_menu_send);
        btnSend.setColorFilter(Color.parseColor("#1B5E20"));
        btnSend.setPadding(20, 0, 10, 0);
        btnSend.setLayoutParams(new LinearLayout.LayoutParams(120, 100));
        bottom.addView(btnSend);

        root.addView(bottom);
        setContentView(root);

        btnSend.setOnClickListener(v -> {
            String text = edtChat.getText().toString().trim();
            if (text.isEmpty() || isCalling) return;

            isCalling = true;
            btnSend.setEnabled(false);
            btnSend.setAlpha(0.3f);

            addUserMessage(text);
            edtChat.setText("");
            callGemini(text);
        });
    }

    private void callGemini(String userPrompt) {
        addBotMessage("🤖 Đang suy nghĩ...");


        String currentTime = new SimpleDateFormat("EEEE, dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(new Date());
        String systemInstruction = "Bối cảnh: Hôm nay là " + currentTime + ". Hãy trả lời người dùng dựa trên thời gian này nếu cần thiết.\n\nCâu hỏi: ";
        String finalPrompt = systemInstruction + userPrompt;
        // ---------------------------------------

        try {
            JSONObject bodyJson = new JSONObject();
            JSONArray contents = new JSONArray();
            JSONObject contentObj = new JSONObject();
            JSONArray parts = new JSONArray();
            parts.put(new JSONObject().put("text", finalPrompt)); // Gửi prompt đã có thời gian
            contentObj.put("parts", parts);
            contents.put(contentObj);
            bodyJson.put("contents", contents);

            RequestBody body = RequestBody.create(bodyJson.toString(), MediaType.get("application/json; charset=utf-8"));
            Request request = new Request.Builder().url(GEMINI_URL).post(body).build();

            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    if (!isDestroyed) handleError("Lỗi kết nối mạng!");
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    if (isDestroyed) return;
                    String resBody = response.body() != null ? response.body().string() : "";

                    runOnUiThread(() -> {
                        removeThinkingView();
                        if (response.code() == 429) {
                            handleError("Bạn đã đạt giới hạn yêu cầu. Thử lại sau 30 giây.");
                            return;
                        }

                        try {
                            JSONObject json = new JSONObject(resBody);
                            JSONArray candidates = json.optJSONArray("candidates");
                            if (candidates != null && candidates.length() > 0) {
                                JSONObject content = candidates.getJSONObject(0).optJSONObject("content");
                                if (content != null) {
                                    String reply = content.getJSONArray("parts").getJSONObject(0).getString("text");
                                    showTypingEffect(reply);
                                    return;
                                }
                            }
                            handleError("AI không thể trả lời câu hỏi này.");
                        } catch (Exception e) {
                            handleError("Lỗi xử lý dữ liệu.");
                        }
                    });
                }
            });
        } catch (Exception e) {
            handleError("Lỗi cấu trúc yêu cầu.");
        }
    }

    private void showTypingEffect(String text) {
        TextView botTv = addMessageBubble("", false);
        typingThread = new Thread(() -> {
            for (int i = 0; i < text.length(); i++) {
                if (isDestroyed) break;
                final String c = String.valueOf(text.charAt(i));
                final boolean last = (i == text.length() - 1);
                handler.post(() -> {
                    if (!isDestroyed) {
                        botTv.append(c);
                        scrollToBottom();
                        if (last) {
                            isCalling = false;
                            btnSend.setEnabled(true);
                            btnSend.setAlpha(1.0f);
                        }
                    }
                });
                try { Thread.sleep(15); } catch (InterruptedException ignored) {}
            }
        });
        typingThread.start();
    }

    private void addUserMessage(String text) { addMessageBubble(text, true); }
    private void addBotMessage(String text) { addMessageBubble(text, false); }

    private TextView addMessageBubble(String message, boolean isUser) {
        LinearLayout row = new LinearLayout(this);
        row.setPadding(0, 15, 0, 15);
        row.setGravity(isUser ? Gravity.END : Gravity.START);

        TextView tv = new TextView(this);
        tv.setText(message);
        tv.setTextSize(15);
        tv.setPadding(35, 25, 35, 25);
        tv.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.75));
        tv.setLineSpacing(0, 1.2f);

        GradientDrawable bg = new GradientDrawable();
        bg.setCornerRadius(40);
        if (isUser) {
            bg.setColor(Color.parseColor("#2E7D32"));
            tv.setTextColor(Color.WHITE);
        } else {
            bg.setColor(Color.WHITE);
            tv.setTextColor(Color.BLACK);
            bg.setStroke(2, Color.parseColor("#DEE2E6"));
        }
        tv.setBackground(bg);

        row.addView(tv);
        chatContainer.addView(row);
        if (!isUser && message.equals("🤖 Đang suy nghĩ...")) currentThinkingView = row;

        animateFadeIn(row);
        scrollToBottom();
        return tv;
    }

    private void handleError(String message) {
        if (isDestroyed) return;
        runOnUiThread(() -> {
            removeThinkingView();
            addBotMessage("❌ " + message);
            isCalling = false;
            btnSend.setEnabled(true);
            btnSend.setAlpha(1.0f);
        });
    }

    private void removeThinkingView() {
        if (currentThinkingView != null) {
            chatContainer.removeView(currentThinkingView);
            currentThinkingView = null;
        }
    }

    private void animateFadeIn(View view) {
        AlphaAnimation anim = new AlphaAnimation(0, 1);
        anim.setDuration(400);
        view.startAnimation(anim);
    }

    private void scrollToBottom() {
        scrollView.post(() -> scrollView.fullScroll(ScrollView.FOCUS_DOWN));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        isDestroyed = true;
        handler.removeCallbacksAndMessages(null);
        if (client != null) client.dispatcher().cancelAll();
        if (typingThread != null && typingThread.isAlive()) typingThread.interrupt();
    }
}