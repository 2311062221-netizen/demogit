package com.example.nckh;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import java.text.DecimalFormat;
import java.util.Calendar;

public class ChartActivity extends AppCompatActivity {

    private TextView tabTuan, tabThang, tabNam;

    // UI Chi tiêu
    private TextView tvChartTitle, tvChartTotal;
    private CustomLineChart lineChart;

    // UI Thu nhập (MỚI THÊM)
    private TextView tvIncomeChartTitle, tvIncomeChartTotal;
    private CustomLineChart incomeLineChart;

    private DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        databaseHelper = new DatabaseHelper(this);

        android.widget.LinearLayout root = new android.widget.LinearLayout(this);
        root.setOrientation(android.widget.LinearLayout.VERTICAL);
        root.setBackgroundColor(android.graphics.Color.parseColor("#F5F7FA"));

        // --- HEADER ---
        CardView header = new CardView(this);
        header.setCardElevation(dpToPx(4));
        android.widget.RelativeLayout headerLayout = new android.widget.RelativeLayout(this);
        headerLayout.setPadding(dpToPx(16), 0, dpToPx(16), 0);
        headerLayout.setLayoutParams(new android.view.ViewGroup.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, dpToPx(60)));
        ImageView btnBack = new ImageView(this);
        btnBack.setImageResource(android.R.drawable.ic_menu_revert);
        btnBack.setColorFilter(android.graphics.Color.parseColor("#333333"));
        android.widget.RelativeLayout.LayoutParams backParams = new android.widget.RelativeLayout.LayoutParams(dpToPx(32), dpToPx(32));
        backParams.addRule(android.widget.RelativeLayout.CENTER_VERTICAL);
        headerLayout.addView(btnBack, backParams);
        btnBack.setOnClickListener(v -> finish());
        TextView tvTitle = new TextView(this);
        tvTitle.setText("Biểu đồ xu hướng 📊");
        tvTitle.setTextSize(18);
        tvTitle.setTypeface(null, android.graphics.Typeface.BOLD);
        tvTitle.setTextColor(android.graphics.Color.parseColor("#333333"));
        android.widget.RelativeLayout.LayoutParams titleParams = new android.widget.RelativeLayout.LayoutParams(android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT, android.widget.RelativeLayout.LayoutParams.WRAP_CONTENT);
        titleParams.addRule(android.widget.RelativeLayout.CENTER_IN_PARENT);
        headerLayout.addView(tvTitle, titleParams);
        header.addView(headerLayout);
        root.addView(header);

        // --- BỌC BODY TRONG SCROLLVIEW (Vì giờ có 2 biểu đồ, cần cuộn dọc) ---
        ScrollView mainScrollView = new ScrollView(this);
        mainScrollView.setLayoutParams(new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.MATCH_PARENT));
        mainScrollView.setVerticalScrollBarEnabled(false);

        // --- BODY ---
        android.widget.LinearLayout body = new android.widget.LinearLayout(this);
        body.setOrientation(android.widget.LinearLayout.VERTICAL);
        body.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));

        // Thanh chọn Tabs
        CardView tabCard = new CardView(this);
        tabCard.setRadius(dpToPx(20));
        tabCard.setCardBackgroundColor(android.graphics.Color.parseColor("#E0E0E0"));
        android.widget.LinearLayout.LayoutParams tabParams = new android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(40));
        tabParams.bottomMargin = dpToPx(16);
        tabCard.setLayoutParams(tabParams);

        android.widget.LinearLayout tabLayout = new android.widget.LinearLayout(this);
        tabLayout.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        tabLayout.setWeightSum(3);
        tabLayout.setPadding(dpToPx(2), dpToPx(2), dpToPx(2), dpToPx(2));

        tabTuan = new TextView(this);
        tabTuan.setText("Tuần");
        tabTuan.setGravity(android.view.Gravity.CENTER);
        tabTuan.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 1.0f));

        tabThang = new TextView(this);
        tabThang.setText("Tháng");
        tabThang.setGravity(android.view.Gravity.CENTER);
        tabThang.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 1.0f));

        tabNam = new TextView(this);
        tabNam.setText("Năm");
        tabNam.setGravity(android.view.Gravity.CENTER);
        tabNam.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.MATCH_PARENT, 1.0f));

        tabLayout.addView(tabTuan);
        tabLayout.addView(tabThang);
        tabLayout.addView(tabNam);
        tabCard.addView(tabLayout);
        body.addView(tabCard);

        // ==========================================
        // KHU VỰC 1: BIỂU ĐỒ CHI TIÊU (Màu Xanh Cyan)
        // ==========================================
        CardView chartCard = new CardView(this);
        chartCard.setRadius(dpToPx(16));
        android.widget.LinearLayout.LayoutParams chartParams = new android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(300));
        chartParams.bottomMargin = dpToPx(16); // Tạo khoảng cách với biểu đồ thu nhập
        chartCard.setLayoutParams(chartParams);

        android.widget.LinearLayout chartLayout = new android.widget.LinearLayout(this);
        chartLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
        chartLayout.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));

        tvChartTitle = new TextView(this);
        tvChartTitle.setTextColor(android.graphics.Color.parseColor("#888888"));

        tvChartTotal = new TextView(this);
        tvChartTotal.setTextSize(24);
        tvChartTotal.setTypeface(null, android.graphics.Typeface.BOLD);
        tvChartTotal.setTextColor(android.graphics.Color.parseColor("#00BCD4")); // Đổi màu số liệu cho dễ nhận biết

        chartLayout.addView(tvChartTitle);
        chartLayout.addView(tvChartTotal);

        android.widget.HorizontalScrollView hScroll = new android.widget.HorizontalScrollView(this);
        android.widget.LinearLayout.LayoutParams hScrollParams = new android.widget.LinearLayout.LayoutParams(-1, -1);
        hScrollParams.topMargin = dpToPx(16);
        hScroll.setLayoutParams(hScrollParams);
        hScroll.setHorizontalScrollBarEnabled(false);
        hScroll.setFillViewport(true);

        lineChart = new CustomLineChart(this, android.graphics.Color.parseColor("#00BCD4"));
        hScroll.addView(lineChart, new android.widget.FrameLayout.LayoutParams(-1, -1));

        chartLayout.addView(hScroll);
        chartCard.addView(chartLayout);
        body.addView(chartCard);

        // ==========================================
        // KHU VỰC 2: BIỂU ĐỒ THU NHẬP (Màu Xanh Lá)
        // ==========================================
        CardView incomeChartCard = new CardView(this);
        incomeChartCard.setRadius(dpToPx(16));
        incomeChartCard.setLayoutParams(new android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, dpToPx(300)));

        android.widget.LinearLayout incomeChartLayout = new android.widget.LinearLayout(this);
        incomeChartLayout.setOrientation(android.widget.LinearLayout.VERTICAL);
        incomeChartLayout.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));

        tvIncomeChartTitle = new TextView(this);
        tvIncomeChartTitle.setTextColor(android.graphics.Color.parseColor("#888888"));

        tvIncomeChartTotal = new TextView(this);
        tvIncomeChartTotal.setTextSize(24);
        tvIncomeChartTotal.setTypeface(null, android.graphics.Typeface.BOLD);
        tvIncomeChartTotal.setTextColor(android.graphics.Color.parseColor("#4CAF50")); // Màu xanh lá cho Thu nhập

        incomeChartLayout.addView(tvIncomeChartTitle);
        incomeChartLayout.addView(tvIncomeChartTotal);

        android.widget.HorizontalScrollView hScrollIncome = new android.widget.HorizontalScrollView(this);
        android.widget.LinearLayout.LayoutParams hScrollIncomeParams = new android.widget.LinearLayout.LayoutParams(-1, -1);
        hScrollIncomeParams.topMargin = dpToPx(16);
        hScrollIncome.setLayoutParams(hScrollIncomeParams);
        hScrollIncome.setHorizontalScrollBarEnabled(false);
        hScrollIncome.setFillViewport(true);

        // Khởi tạo chart thu nhập với màu xanh lá
        incomeLineChart = new CustomLineChart(this, android.graphics.Color.parseColor("#4CAF50"));
        hScrollIncome.addView(incomeLineChart, new android.widget.FrameLayout.LayoutParams(-1, -1));

        incomeChartLayout.addView(hScrollIncome);
        incomeChartCard.addView(incomeChartLayout);
        body.addView(incomeChartCard);

        // Thêm body vào ScrollView
        mainScrollView.addView(body);
        root.addView(mainScrollView);
        setContentView(root);

        // Logic tương tác
        kichHoatTab(tabTuan);

        tabTuan.setOnClickListener(v -> kichHoatTab(tabTuan));
        tabThang.setOnClickListener(v -> kichHoatTab(tabThang));
        tabNam.setOnClickListener(v -> kichHoatTab(tabNam));
    }

    // =========================================================================
    // HÀM TÍNH TOÁN DỮ LIỆU TỪ DATABASE VÀ ĐỔ VÀO BIỂU ĐỒ
    // =========================================================================
    private void kichHoatTab(TextView tab) {
        // Reset giao diện tab
        tabTuan.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        tabTuan.setTextColor(android.graphics.Color.parseColor("#555555"));
        tabThang.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        tabThang.setTextColor(android.graphics.Color.parseColor("#555555"));
        tabNam.setBackgroundColor(android.graphics.Color.TRANSPARENT);
        tabNam.setTextColor(android.graphics.Color.parseColor("#555555"));

        android.graphics.drawable.GradientDrawable bgXanh = new android.graphics.drawable.GradientDrawable();
        bgXanh.setColor(android.graphics.Color.parseColor("#00BCD4"));
        bgXanh.setCornerRadius(dpToPx(18));

        tab.setBackground(bgXanh);
        tab.setTextColor(android.graphics.Color.WHITE);

        Calendar cal = Calendar.getInstance();
        int currentYear = cal.get(Calendar.YEAR);
        int currentMonth = cal.get(Calendar.MONTH) + 1;

        long totalExpense = 0;
        long totalIncome = 0;

        float[] expenseData = null;
        float[] incomeData = null;
        String[] chartLabels = null;

        String titleExpense = "";
        String titleIncome = "";

        if (tab == tabTuan) {
            titleExpense = "Tổng chi tiêu tuần này";
            titleIncome = "Tổng thu nhập tuần này";
            expenseData = new float[7];
            incomeData = new float[7];
            chartLabels = new String[]{"T2", "T3", "T4", "T5", "T6", "T7", "CN"};

            cal.setFirstDayOfWeek(Calendar.MONDAY);
            cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);

            for (int i = 0; i < 7; i++) {
                int d = cal.get(Calendar.DAY_OF_MONTH);
                int m = cal.get(Calendar.MONTH) + 1;
                int y = cal.get(Calendar.YEAR);

                long chi = databaseHelper.layTongTienTheoNgayVaLoai(d, m, y, 2);
                long thu = databaseHelper.layTongTienTheoNgayVaLoai(d, m, y, 1);

                expenseData[i] = (float) chi;
                incomeData[i] = (float) thu;

                totalExpense += chi;
                totalIncome += thu;

                cal.add(Calendar.DAY_OF_MONTH, 1);
            }

        } else if (tab == tabThang) {
            titleExpense = "Tổng chi tiêu tháng này";
            titleIncome = "Tổng thu nhập tháng này";
            expenseData = new float[4];
            incomeData = new float[4];
            chartLabels = new String[]{"Tuần 1", "Tuần 2", "Tuần 3", "Tuần 4"};

            int maxDaysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);

            for (int d = 1; d <= maxDaysInMonth; d++) {
                long chi = databaseHelper.layTongTienTheoNgayVaLoai(d, currentMonth, currentYear, 2);
                long thu = databaseHelper.layTongTienTheoNgayVaLoai(d, currentMonth, currentYear, 1);

                totalExpense += chi;
                totalIncome += thu;

                if (d <= 7) {
                    expenseData[0] += chi;
                    incomeData[0] += thu;
                } else if (d <= 14) {
                    expenseData[1] += chi;
                    incomeData[1] += thu;
                } else if (d <= 21) {
                    expenseData[2] += chi;
                    incomeData[2] += thu;
                } else {
                    expenseData[3] += chi;
                    incomeData[3] += thu;
                }
            }

        } else if (tab == tabNam) {
            titleExpense = "Tổng chi tiêu năm nay";
            titleIncome = "Tổng thu nhập năm nay";
            expenseData = new float[12];
            incomeData = new float[12];
            chartLabels = new String[]{"T1", "T2", "T3", "T4", "T5", "T6", "T7", "T8", "T9", "T10", "T11", "T12"};

            for (int m = 1; m <= 12; m++) {
                long chi = databaseHelper.layTongTienThangVaLoai(m, currentYear, 2);
                long thu = databaseHelper.layTongTienThangVaLoai(m, currentYear, 1);

                expenseData[m - 1] = (float) chi;
                incomeData[m - 1] = (float) thu;

                totalExpense += chi;
                totalIncome += thu;
            }
        }

        // Cập nhật UI Chi tiêu
        tvChartTitle.setText(titleExpense);
        tvChartTotal.setText(dinhDangTien(totalExpense));
        lineChart.setData(expenseData, chartLabels);

        // Cập nhật UI Thu nhập
        tvIncomeChartTitle.setText(titleIncome);
        tvIncomeChartTotal.setText("+" + dinhDangTien(totalIncome));
        incomeLineChart.setData(incomeData, chartLabels);
    }

    private String dinhDangTien(long tien) {
        DecimalFormat formatter = new DecimalFormat("###,###,###");
        return formatter.format(tien) + "đ";
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }

    // =========================================================================
    // CỖ MÁY VẼ BIỂU ĐỒ ĐƯỜNG (Có hỗ trợ đổi màu chủ đạo)
    // =========================================================================
    class CustomLineChart extends View {
        private float[] dataPoints = new float[0];
        private String[] xLabels = new String[0];

        private Paint linePaint, pointPaint, innerPointPaint, textPaint, gridPaint;

        public CustomLineChart(Context context, int themeColor) {
            super(context);

            linePaint = new Paint();
            linePaint.setColor(themeColor); // Sử dụng màu được truyền vào
            linePaint.setStrokeWidth(dpToPx(3));
            linePaint.setStyle(Paint.Style.STROKE);
            linePaint.setAntiAlias(true);

            pointPaint = new Paint();
            pointPaint.setColor(themeColor); // Sử dụng màu được truyền vào
            pointPaint.setStyle(Paint.Style.FILL);
            pointPaint.setAntiAlias(true);

            innerPointPaint = new Paint();
            innerPointPaint.setColor(android.graphics.Color.WHITE);
            innerPointPaint.setStyle(Paint.Style.FILL);
            innerPointPaint.setAntiAlias(true);

            textPaint = new Paint();
            textPaint.setColor(android.graphics.Color.parseColor("#888888"));
            textPaint.setTextSize(dpToPx(12));
            textPaint.setTextAlign(Paint.Align.CENTER);
            textPaint.setAntiAlias(true);

            gridPaint = new Paint();
            gridPaint.setColor(android.graphics.Color.parseColor("#EEEEEE"));
            gridPaint.setStrokeWidth(dpToPx(1));
            gridPaint.setStyle(Paint.Style.STROKE);
            gridPaint.setAntiAlias(true);
        }

        public void setData(float[] data, String[] labels) {
            this.dataPoints = data;
            this.xLabels = labels;

            int minWidthPerPoint = dpToPx(65);
            int paddingHorizontal = dpToPx(30);

            int requiredWidth = ((data.length - 1) * minWidthPerPoint) + (2 * paddingHorizontal);
            int screenWidth = getResources().getDisplayMetrics().widthPixels - dpToPx(64);
            int finalWidth = Math.max(requiredWidth, screenWidth);

            setLayoutParams(new android.widget.FrameLayout.LayoutParams(finalWidth, android.view.ViewGroup.LayoutParams.MATCH_PARENT));

            requestLayout();
            invalidate();
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (dataPoints == null || dataPoints.length < 2) return;

            int width = getWidth();
            int height = getHeight();
            if (height <= 0) return;

            int paddingBottom = dpToPx(40);
            int paddingTop = dpToPx(30);
            int paddingHorizontal = dpToPx(30);

            int chartHeight = height - paddingBottom - paddingTop;
            int chartWidth = width - (2 * paddingHorizontal);

            float maxData = 0;
            for (float val : dataPoints) {
                if (val > maxData) maxData = val;
            }
            if (maxData == 0) maxData = 1;

            maxData = maxData * 1.15f;

            float xStep = (float) chartWidth / (dataPoints.length - 1);

            Path path = new Path();

            // VẼ LƯỚI DỌC VÀ CHỮ
            for (int i = 0; i < dataPoints.length; i++) {
                float x = paddingHorizontal + (i * xStep);
                canvas.drawLine(x, paddingTop, x, height - paddingBottom + dpToPx(5), gridPaint);

                if (i < xLabels.length) {
                    canvas.drawText(xLabels[i], x, height - dpToPx(12), textPaint);
                }
            }

            // VẼ ĐƯỜNG KẺ GẤP KHÚC
            for (int i = 0; i < dataPoints.length; i++) {
                float x = paddingHorizontal + (i * xStep);
                float y = paddingTop + chartHeight - (dataPoints[i] / maxData * chartHeight);

                if (i == 0) {
                    path.moveTo(x, y);
                } else {
                    path.lineTo(x, y);
                }
            }
            canvas.drawPath(path, linePaint);

            // VẼ CÁC NỐT TRÒN
            for (int i = 0; i < dataPoints.length; i++) {
                float x = paddingHorizontal + (i * xStep);
                float y = paddingTop + chartHeight - (dataPoints[i] / maxData * chartHeight);

                canvas.drawCircle(x, y, dpToPx(6), pointPaint);
                canvas.drawCircle(x, y, dpToPx(3), innerPointPaint);
            }
        }
    }
}