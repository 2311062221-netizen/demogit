package com.example.nckh;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class BudgetActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_budget);

        // ==========================================
        // 1. XỬ LÝ NHẤN VÀO CÁC TÍNH NĂNG (CARDS)
        // ==========================================

        CardView cardBudgetDetail = findViewById(R.id.cardBudgetDetail);
        CardView cardSavings = findViewById(R.id.cardSavings);
        CardView cardDebt = findViewById(R.id.cardDebt);
        CardView cardChallenge = findViewById(R.id.cardChallenge);

        // Đã thêm if != null để đảm bảo app KHÔNG BAO GIỜ bị văng nếu lỗi XML
        if (cardBudgetDetail != null) {
            cardBudgetDetail.setOnClickListener(v -> {
                Toast.makeText(this, "Mở trang thiết lập Ngân sách", Toast.LENGTH_SHORT).show();
                // startActivity(new Intent(BudgetActivity.this, BudgetDetailActivity.class));
            });
        }

        if (cardSavings != null) {
            cardSavings.setOnClickListener(v -> {
                Toast.makeText(this, "Mở trang Tiết kiệm", Toast.LENGTH_SHORT).show();
                // startActivity(new Intent(BudgetActivity.this, SavingsActivity.class));
            });
        }

        if (cardDebt != null) {
            cardDebt.setOnClickListener(v -> {
                Toast.makeText(this, "Mở trang Món nợ", Toast.LENGTH_SHORT).show();
                // startActivity(new Intent(BudgetActivity.this, DebtActivity.class));
            });
        }

        if (cardChallenge != null) {
            cardChallenge.setOnClickListener(v -> {
                Toast.makeText(this, "Mở trang Thử thách", Toast.LENGTH_SHORT).show();
                // startActivity(new Intent(BudgetActivity.this, ChallengeActivity.class));
            });
        }


        // ==========================================
        // 2. XỬ LÝ THANH ĐIỀU HƯỚNG DƯỚI CÙNG
        // ==========================================
        BottomNavigationView bottomNavigation = findViewById(R.id.bottom_navigation);

        if (bottomNavigation != null) {
            // Làm sáng tab hiện tại
            bottomNavigation.setSelectedItemId(R.id.nav_budget);

            bottomNavigation.setOnItemSelectedListener(item -> {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(BudgetActivity.this, MainActivity.class));
                    overridePendingTransition(0, 0);
                    finish();
                    return true;

                } else if (itemId == R.id.nav_calendar) {
                    startActivity(new Intent(BudgetActivity.this, CalendarActivity.class));
                    overridePendingTransition(0, 0);
                    finish();
                    return true;

                } else if (itemId == R.id.nav_budget) {
                    // Đang ở trang Ngân sách rồi thì không làm gì
                    return true;

                } else if (itemId == R.id.nav_settings) {
                    startActivity(new Intent(BudgetActivity.this, SettingsActivity.class));
                    overridePendingTransition(0, 0);
                    finish();
                    return true;
                }

                return false;
            });
        }
    }
}