package com.example.nckh;

import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.CalendarView;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

import java.text.DecimalFormat;
import java.util.Calendar;

public class CalendarActivity extends AppCompatActivity {

    private TextView tvNgayChon, tvTongThu, tvTongChi, tvSoDuNgay;
    private android.widget.LinearLayout llDanhSachGiaoDich;
    private DatabaseHelper dbHelper;

    private int currentDay;
    private int currentMonth;
    private int currentYear;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);

        // KẾT NỐI VỚI FILE XML VỪA TẠO
        setContentView(R.layout.activity_calendar);

        dbHelper = new DatabaseHelper(this);

        // ÁNH XẠ CÁC VIEW TỪ XML SANG JAVA
        tvNgayChon = findViewById(R.id.tvNgayChon);
        tvTongThu = findViewById(R.id.tvTongThu);
        tvTongChi = findViewById(R.id.tvTongChi);
        tvSoDuNgay = findViewById(R.id.tvSoDuNgay);
        llDanhSachGiaoDich = findViewById(R.id.llDanhSachGiaoDich);
        CalendarView calendarView = findViewById(R.id.calendarView);
        ImageView btnBack = findViewById(R.id.btnBack);
        BottomNavigationView bottomNav = findViewById(R.id.bottom_navigation);

        // SỰ KIỆN NÚT BACK
        btnBack.setOnClickListener(v -> finish());

        // XỬ LÝ THANH BOTTOM NAVIGATION (Đồng bộ)
        if (bottomNav != null) {
            bottomNav.setSelectedItemId(R.id.nav_calendar); // Sáng tab Lịch
            bottomNav.setOnItemSelectedListener(item -> {
                int itemId = item.getItemId();
                if (itemId == R.id.nav_home) {
                    startActivity(new Intent(CalendarActivity.this, MainActivity.class));
                    overridePendingTransition(0, 0);
                    finish();
                    return true;
                } else if (itemId == R.id.nav_calendar) {
                    return true; // Đang ở Lịch rồi thì không làm gì
                } else if (itemId == R.id.nav_budget) {
                    startActivity(new Intent(CalendarActivity.this, BudgetActivity.class));
                    overridePendingTransition(0, 0);
                    finish();
                    return true;
                } else if (itemId == R.id.nav_settings) {
                    startActivity(new Intent(CalendarActivity.this, SettingsActivity.class));
                    overridePendingTransition(0, 0);
                    finish();
                    return true;
                }
                return false;
            });
        }

        // =====================================
        // LOGIC LỊCH CỦA BẠN (GIỮ NGUYÊN)
        // =====================================
        Calendar today = Calendar.getInstance();
        currentDay = today.get(Calendar.DAY_OF_MONTH);
        currentMonth = today.get(Calendar.MONTH);
        currentYear = today.get(Calendar.YEAR);

        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            currentDay = dayOfMonth;
            currentMonth = month;
            currentYear = year;
            capNhatDuLieuNgay(currentDay, currentMonth, currentYear);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        capNhatDuLieuNgay(currentDay, currentMonth, currentYear);
    }

    private void capNhatDuLieuNgay(int day, int month, int year) {
        int thangThucTe = month + 1;
        Calendar cal = Calendar.getInstance();
        cal.set(year, month, day);
        int thu = cal.get(Calendar.DAY_OF_WEEK);
        String[] tenThu = {"", "CN", "Th 2", "Th 3", "Th 4", "Th 5", "Th 6", "Th 7"};
        tvNgayChon.setText(tenThu[thu] + ", " + day + " thg " + thangThucTe + ", " + year);

        llDanhSachGiaoDich.removeAllViews();

        long tongThu = dbHelper.layTongTienTheoNgayVaLoai(day, thangThucTe, year, 1);
        long tongChi = dbHelper.layTongTienTheoNgayVaLoai(day, thangThucTe, year, 2);
        long soDu = tongThu - tongChi;

        DecimalFormat formatter = new DecimalFormat("#,###");

        tvTongChi.setText("▼ " + formatter.format(tongChi).replace(",", ".") + "đ");
        tvTongThu.setText("▲ " + formatter.format(tongThu).replace(",", ".") + "đ");
        tvSoDuNgay.setText(formatter.format(soDu).replace(",", ".") + "đ");

        Cursor cursor = dbHelper.layDanhSachGiaoDichTheoNgay(day, thangThucTe, year);
        boolean hasData = false;

        if (cursor != null) {
            while (cursor.moveToNext()) {
                hasData = true;
                long soTien = cursor.getLong(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_SO_TIEN));
                String danhMuc = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_DANH_MUC));
                String ghiChu = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_GHI_CHU));
                int loai = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COLUMN_LOAI_GIAO_DICH));

                String formattedTien = formatter.format(soTien).replace(",", ".");
                veGiaoDichLenManHinh(formattedTien, danhMuc, ghiChu, loai);
            }
            cursor.close();
        }

        if (!hasData) {
            TextView tvRong = new TextView(this);
            tvRong.setText("Không có giao dịch nào trong ngày này.");
            tvRong.setGravity(android.view.Gravity.CENTER);
            tvRong.setPadding(0, dpToPx(32), 0, 0);
            tvRong.setTextColor(android.graphics.Color.parseColor("#888888"));
            llDanhSachGiaoDich.addView(tvRong);
        }
    }

    // Code tạo giao diện thẻ Giao dịch bằng code Java (Giữ nguyên)
    private void veGiaoDichLenManHinh(String soTien, String danhMuc, String ghiChu, int loaiGiaoDich) {
        CardView card = new CardView(this);
        android.widget.LinearLayout.LayoutParams cardParams = new android.widget.LinearLayout.LayoutParams(
                android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT);
        cardParams.setMargins(0, 0, 0, dpToPx(12));
        card.setLayoutParams(cardParams);
        card.setRadius(dpToPx(16));
        card.setCardElevation(0);
        card.setCardBackgroundColor(android.graphics.Color.WHITE);

        android.widget.LinearLayout inner = new android.widget.LinearLayout(this);
        inner.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        inner.setPadding(dpToPx(16), dpToPx(16), dpToPx(16), dpToPx(16));
        inner.setGravity(android.view.Gravity.CENTER_VERTICAL);

        CardView iconBg = new CardView(this);
        iconBg.setRadius(dpToPx(24));
        iconBg.setCardElevation(0);
        iconBg.setCardBackgroundColor(android.graphics.Color.parseColor(loaiGiaoDich == 1 ? "#E8F5E9" : "#FFEBEE"));
        android.widget.LinearLayout.LayoutParams iconBgParams = new android.widget.LinearLayout.LayoutParams(dpToPx(48), dpToPx(48));
        iconBgParams.setMarginEnd(dpToPx(16));
        iconBg.setLayoutParams(iconBgParams);

        ImageView icon = new ImageView(this);
        icon.setImageResource(loaiGiaoDich == 1 ? android.R.drawable.ic_input_add : android.R.drawable.ic_menu_agenda);
        icon.setColorFilter(android.graphics.Color.parseColor(loaiGiaoDich == 1 ? "#4CAF50" : "#FF4B4B"));
        icon.setPadding(dpToPx(12), dpToPx(12), dpToPx(12), dpToPx(12));
        iconBg.addView(icon);
        inner.addView(iconBg);

        android.widget.LinearLayout textCol = new android.widget.LinearLayout(this);
        textCol.setOrientation(android.widget.LinearLayout.VERTICAL);
        textCol.setLayoutParams(new android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1.0f));

        TextView tvCat = new TextView(this);
        tvCat.setText(danhMuc == null || danhMuc.isEmpty() ? (loaiGiaoDich == 1 ? "Thu nhập" : "Chi tiêu") : danhMuc);
        tvCat.setTextSize(16);
        tvCat.setTypeface(null, android.graphics.Typeface.BOLD);
        tvCat.setTextColor(android.graphics.Color.parseColor("#333333"));
        textCol.addView(tvCat);

        if (ghiChu != null && !ghiChu.isEmpty()) {
            TextView tvNote = new TextView(this);
            tvNote.setText(ghiChu);
            tvNote.setTextSize(13);
            tvNote.setTextColor(android.graphics.Color.parseColor("#888888"));
            tvNote.setPadding(0, dpToPx(2), 0, 0);
            textCol.addView(tvNote);
        }
        inner.addView(textCol);

        TextView tvAmt = new TextView(this);
        String prefix = (loaiGiaoDich == 1) ? "▲ " : "▼ ";
        String colorHex = (loaiGiaoDich == 1) ? "#009688" : "#FF4B4B";

        tvAmt.setText(prefix + soTien + "đ");
        tvAmt.setTextSize(15);
        tvAmt.setTypeface(null, android.graphics.Typeface.BOLD);
        tvAmt.setTextColor(android.graphics.Color.parseColor(colorHex));
        inner.addView(tvAmt);

        card.addView(inner);
        llDanhSachGiaoDich.addView(card);
    }

    private int dpToPx(int dp) {
        return (int) (dp * getResources().getDisplayMetrics().density);
    }
}