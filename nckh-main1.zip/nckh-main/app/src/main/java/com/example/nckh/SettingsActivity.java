package com.example.nckh;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class SettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        // Nút chuyển sang màn hình Cài đặt tài khoản
        CardView btnAccountSettings = findViewById(R.id.btnAccountSettings);
        if (btnAccountSettings != null) {
            btnAccountSettings.setOnClickListener(v -> {
                startActivity(new Intent(SettingsActivity.this, AccountSettingsActivity.class));
            });
        }

        // Xử lý Bottom Navigation
        BottomNavigationView bottomNavigation = findViewById(R.id.bottom_navigation);

        if (bottomNavigation != null) {
            bottomNavigation.setSelectedItemId(R.id.nav_settings); // Sáng tab Cài đặt

            bottomNavigation.setOnItemSelectedListener(item -> {
                int itemId = item.getItemId();

                if (itemId == R.id.nav_home) {
                    // Chuyển sang Trang chủ (MainActivity)
                    startActivity(new Intent(SettingsActivity.this, MainActivity.class));
                    overridePendingTransition(0, 0); // Tắt hiệu ứng chuyển trang mặc định cho mượt
                    finish();
                    return true;

                } else if (itemId == R.id.nav_calendar) {
                    // Chuyển sang Trang Lịch (đảm bảo bạn đã tạo CalendarActivity)
                    startActivity(new Intent(SettingsActivity.this, CalendarActivity.class));
                    overridePendingTransition(0, 0);
                    finish();
                    return true;

                } else if (itemId == R.id.nav_budget) {
                    // Chuyển sang Trang Ngân sách (đảm bảo bạn đã tạo BudgetActivity)
                    startActivity(new Intent(SettingsActivity.this, BudgetActivity.class));
                    overridePendingTransition(0, 0);
                    finish();
                    return true;

                } else if (itemId == R.id.nav_settings) {
                    // Đang ở tab Cài đặt rồi thì không làm gì cả
                    return true;
                }

                return false;
            });
        }
    }
}