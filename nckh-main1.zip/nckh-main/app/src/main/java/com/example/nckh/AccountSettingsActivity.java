package com.example.nckh;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class AccountSettingsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_account_settings);

        ImageView btnBack = findViewById(R.id.btnBack);
        btnBack.setOnClickListener(v -> finish()); // Nhấn nút back để quay lại

        // Cập nhật cả TEXT và ICON cho từng mục
        // (Tôi dùng các icon hệ thống có sẵn của Android để bạn không bị lỗi đỏ)
        setupSettingItem(R.id.item1, "Tính cách của AI", android.R.drawable.ic_menu_myplaces);
        setupSettingItem(R.id.item2, "Ngôn ngữ phản hồi", android.R.drawable.ic_menu_sort_alphabetically);
        setupSettingItem(R.id.item3, "Mục tiêu tài chính", android.R.drawable.ic_menu_compass);
        setupSettingItem(R.id.item4, "Chủ đề màu sắc", android.R.drawable.ic_menu_gallery);
        setupSettingItem(R.id.item5, "Định dạng số tiền", android.R.drawable.ic_menu_sort_by_size);
        setupSettingItem(R.id.item6, "Xuất/Nhập CSV", android.R.drawable.ic_menu_save);
    }

    // Hàm hỗ trợ gán chữ và hình ảnh cho giao diện dùng chung (include)
    private void setupSettingItem(int itemId, String title, int iconResId) {
        android.view.View view = findViewById(itemId);
        if (view != null) {
            TextView tvTitle = view.findViewById(R.id.itemTitle);
            ImageView ivIcon = view.findViewById(R.id.itemIcon);

            if (tvTitle != null) {
                tvTitle.setText(title);
            }
            if (ivIcon != null) {
                ivIcon.setImageResource(iconResId);
                // Đổi màu icon thành màu xám đen cho đẹp
                ivIcon.setColorFilter(android.graphics.Color.parseColor("#555555"));
            }
        }
    }
}